<?php
/**
 * Feature Sidebar Template
 *
 * The Feature sidebar first checks for an active sidebar of 'utility-feature'.  If this sidebar isn't
 * active, it displays a list of top articles from the month.  The 'utility-feature' sidebar isn't registered
 * by default.  If you want to use it, you must register a sidebar with that specific ID.
 *
 * @package News
 * @subpackage Template
 */

if ( is_active_sidebar( 'feature' ) ) : ?>

	<div id="sidebar-feature" class="sidebar utility">

		<?php dynamic_sidebar( 'feature' ); ?>

	</div><!-- #sidebar-feature .utility -->

<?php else : ?>

	<div id="sidebar-feature" class="sidebar utility">
	
	<div id="sidebarArchiveTabView" class="yui-navset">

				 <ul class="yui-nav">
					<li class="selected"><a href="#video-tabs-1"><em><?php _e( 'Top Tags', hybrid_get_textdomain() ); ?></em></a></li>
					<li><a href="#video-tabs-2"><em><?php _e( 'Top Clicks', hybrid_get_textdomain() ); ?></em></a></li>
					<li><a href="#video-tabs-3"><em><?php _e( 'Top Topics', hybrid_get_textdomain() ); ?></em></a></li>
				</ul><!-- .ui-tabs-nav -->
				
						<div class="yui-content">

				<div id="video-tabs-1">
				 <div class="tagsmyAccordion1"> 
<div class="archiveheader"><strong><?php _e('[+]&nbsp;Most Popular Topics', 'papuamerdeka') ?></strong></div>
	  <?php
      $noOfTags = 10; 
      $noOfPosts = 5;      
      $cloudRight = get_tags("orderby=count&order=DESC&number=$noOfTags");
      foreach((array)$cloudRight as $tagRight) : ?>
	<div class="yui-cms-accordion multiple fade fixIE" id="mylist-first-accordion">	
          <?php        
          $postsRight = new WP_Query();
          $postsRight->query("tag={$tagRight->slug}&showposts=$noOfPosts");        
          ?>            
          <?php if ( $postsRight->have_posts() ) :?>		  
              	<div class="yui-cms-item" id="mylist-first-element"><h3 style="text-transform:capitalize;"><a href="#" class="accordionRemoveItem action" title="click to remove">&nbsp;</a> 
		      <a href="#" class="accordionToggleItem action" title="click to expand">&nbsp;</a> &raquo;&nbsp;<?php echo $tagRight->name ?></a></h3>
              <div class="bd">
              <div class="fixed">
			<?php while ( $postsRight->have_posts() ) : $postsRight->the_post(); ?>
             <ul class='listing'><li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
              </ul>	
			  <?php endwhile;?> </div></div> 
          <?php endif; ?></div> 	  
      <?php unset($postsRight); echo '</div>'; endforeach; ?>
</div><br clear="all">
				</div><!-- .ui-tabs-panel -->

				<div id="video-tabs-2">
		<div class="widget-top-articles">

			<div class="widget-inside">

				<h3 class="widget-title">[+]&nbsp;<?php _e('Popular Post', 'hybrid') ?></h3>

				<?php $loop = new WP_Query( array( 'meta_key' => 'Views', 'orderby' => 'meta_value', 'monthnum' => date( 'm' ), 'posts_per_page' => 5 ) ); ?>

				<?php if ( !$loop->have_posts() ) $loop = new WP_Query( array( 'orderby' => 'comment_count', 'posts_per_page' => 3, 'ignore_sticky_posts' => true ) ); ?>

				<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

					<div class="<?php hybrid_entry_class(); ?>">

						<?php get_the_image( array( 'meta_key' => array( 'Thumbnail' ), 'size' => 'news-thumbnail' ) ); ?>

						<?php echo apply_atomic_shortcode( 'entry_title', the_title( '<h4 class="entry-title"><a href="' . get_permalink() . '" title="' . the_title_attribute( 'echo=0' ) . '" rel="bookmark">', '</a></h4>', false ) ); ?>

						<?php echo apply_atomic_shortcode( 'byline', '<div class="byline">[entry-published]</div>' ); ?>

					</div><!-- .hentry -->

				<?php endwhile; ?>

				<?php $view_more = news_get_post_by_meta( '_wp_page_template', 'page-template-popular.php' ); ?>

				<?php if ( !empty( $view_more ) ) { ?>
					<a class="view-more" href="<?php echo get_permalink( $view_more ); ?>" title="<?php esc_attr_e( 'View more popular posts', 'news' ); ?>"><?php _e( 'View More', 'news' ); ?></a>
				<?php } ?>

			</div><!-- .widget-inside -->


		<?php wp_reset_query(); ?>
</div><!--div class="widget-top-articles"> -->

				</div><!-- .ui-tabs-panel 2 -->		

		<div id="video-tabs-3">
	<div class="sidebarheader">
				<h3 class="widget-title">&nbsp;<?php _e('[+]&nbsp;Popular Categories', hybrid_get_textdomain() ); ?></h3>
			
			<ul class="listing"><?php wp_list_categories('number=10&show_count=1&orderby=count&order=DESC&title_li=') ?></ul>	  
	
		</div><!-- .sidebarheader -->
			</div><!-- .ui-tabs-panel3 -->

		</div><!--.yui-content -->
		</div><!-- id="sidebarArchiveTabView" class="yui-navset" -->
<script type="text/javascript" charset="utf-8">
var oTabView = new YAHOO.widget.TabView("sidebarArchiveTabView");
</script>
	</div><!-- #sidebar-feature .utility -->

<?php endif; ?>