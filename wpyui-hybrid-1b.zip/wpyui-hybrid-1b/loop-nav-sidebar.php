<?php
/**
 * Sidebar Loop Navigation Template
 *
 * Displays information at the top of the page about archive and search results when viewing those pages.  
 * This is not shown on the home page and singular views.
 *
 * @package News
 * @subpackage Template
 * PMNews added tagBreadcrumb for is_singular ('post')) meta
 */
?>

   <div class="tagsmyAccordion1"> 
	<div class="yui-cms-accordion multiple fade fixIE" id="mylist-first-accordion">			  
              	<div class="yui-cms-item selected" id="mylist-first-element"><h3 style="text-transform:capitalize;"><a href="#" class="accordionRemoveItem action" title="click to remove">&nbsp;</a> 
		      <a href="#" class="accordionToggleItem action" title="click to expand">&nbsp;</a> &raquo;&nbsp;<?php echo $tagRight->name ?></h3>
              <div class="bd">
              <div class="fixed">
			  
<?php echo news_navigation(); /* refer to "context.php" */ ?> 

				</div><!-- .fixed -->
			</div><!-- .bd -->
		</div><!-- .yui-cms-item -->
		</div><!-- .yui-cms-accordion --> 
	</div><!-- .tagsmyAccordion1 --> 
	
	<?php if ( is_home() || is_front_page() || is_page_template('page-home.php') || is_page_template('page-front-page.php')) : ?>

  <div class="tagsmyAccordion1"> 
 	<div class="yui-cms-accordion multiple fade fixIE">
		<div class="yui-cms-item yui-panel">
 			<div class="bd">
	<div class="fixed">
 	<?php echo do_shortcode('[entry-google-breadcrumb]'); ?>			
	<?php echo do_shortcode('[entry-sidebar-pagination]'); ?>	

	</div><!-- .fixed -->
		</div><!-- .bd -->
	<div class="actions">
	 <a href="#" class="accordionToggleItem">&nbsp;</a> 
	</div>	
		</div><!-- .yui-cms-item yui-panel-->
		</div><!-- .yui-cms-accordion multiple fade fixIE -->
		</div><!-- class="tagsmyAccordion1" -->
 
  <div class="tagsmyAccordion1"> 
 	<div class="yui-cms-accordion multiple fade fixIE">
		<div class="yui-cms-item yui-panel">
 			<div class="bd">
	<div class="fixed">
<?php include( trailingslashit( STYLESHEETPATH ) . 'library/content/quick-count.php' ); ?>	

	</div><!-- .loop-meta -->
		</div><!-- .loop-meta -->
	<div class="actions">
	 <a href="#" class="accordionToggleItem">&nbsp;</a> 
	</div>	
		</div><!-- .loop-meta -->
		</div><!-- .yui-cms-accordion multiple fade fixIE -->
		</div><!-- class="tagsmyAccordion1" -->
		
   <div class="tagsmyAccordion1"> 
	<div class="yui-cms-accordion multiple fade fixIE" id="mylist-first-accordion">			  
              	<div class="yui-cms-item" id="mylist-first-element"><h3 style="text-transform:capitalize;"><a href="#" class="accordionRemoveItem action" title="click to remove">&nbsp;</a> 
		      <a href="#" class="accordionToggleItem action" title="click to expand">&nbsp;</a> &raquo;&nbsp;<?php echo $tagRight->name ?></a></h3>
              <div class="bd">
              <div class="fixed">
			  
 	<?php get_sidebar ('home'); ?> 

	 </div>
	 </div> </div>
	</div> 
	</div> 

<?php elseif ( is_singular('post') ) : ?>

<?php echo apply_atomic_shortcode( 'entry_utility', '<div class="entry-utility">' . __( '[entry-print-link]<span class=vsep></span>[entry-email-link before=" /"]<span class=vsep></span>[entry-facebook-link]<span class=vsep></span> [entry-twitter-link] <span class=vsep></span> [entry-googleplus-link] <span class=vsep></span> [entry-cakifo-twitter] <span class=vsep></span>[entry-fblike-live-link]', hybrid_get_textdomain() ) . '</div>' ); ?>

<?php
{ $postnote = get_post_meta
($post->ID, 'postnote', $single = true); ?>
<div class="breadcrumbs entry-postnote">
<?php if($postnote !== '') echo $postnote; 
else
_e( 'No Editorial Note:', hybrid_get_textdomain() );
} ?>
</div><!-- entry-postnote-->
<?php ?>
	
 <?php elseif ( is_category() ) : ?>
 
 <div class="breadcrumbs">
<div class="hd"><span class="gr" style="font-size:120%;">&nbsp;&raquo;&nbsp;&rang;&nbsp;<?php echo single_cat_title(); ?></span>&nbsp;&laquo;&nbsp;&rang;&nbsp;<span class="single-cat-feedlink cat-feedlink"><a href="<?php echo get_category_feed_link($cat, ''); ?>" title="<?php printf(__('Subscribe to %s', 'hybrid-child'), get_cat_name($cat)); ?>"><?php printf(__('Subscribe to %s', 'hybrid-child'), get_cat_name($cat)); ?></span></a>
</div>
<div class="thumbnail"><?php echo do_action( 'taxonomy_image_plugin_print_image_html', 'detail' );?>
</div>
<?php $description = category_description( '', get_query_var( 'taxonomy' ) ); ?>
<?php if ( !empty( $description ) ) echo '<span class="headlines">' . $description . '</span>'; ?>

<?php
		$this_category = get_category($cat);
		if (get_category_children($this_category->cat_ID) != "") {		
		echo '<h3 class="widget-title">';
		echo '"';
		echo single_cat_title();
	echo '"&raquo;&nbsp;';
		echo 'has <em>Sub-Category(ies)</em>:</h3>'; 
			wp_list_categories('optioncount=1&orderby=id&title_li=
		&use_desc_for_title=1&child_of='.$this_category->cat_ID); 
}
?>
	</div><!-- .yui-cms-item yui-panel -->

	<?php  
	if ( current_theme_supports( 'popular-inthis' ) ) {
		echo '<div class=breadcrumbs>';
	include( trailingslashit( STYLESHEETPATH ) . 'library/extensions/popinthiscat.php' );
	echo '</div>';
	} ?>

	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('sidebar-archive') ) : else : ?><?php endif; ?> 

	<?php elseif ( is_tag() ) : ?>		
			 <div class="breadcrumbs">
				<div class="hd"><span class="gr">&nbsp;&raquo;&nbsp;&rang;&nbsp;<?php echo single_tag_title(); ?></span>
				<span class="single-cat-feedlink"><a class="icon-rss" href="<?php echo get_tag_feed_link( $tag->term_id ); ?>">RSS</a>&nbsp;<a href="<?php echo $tag_link; ?>"><?php echo esc_html( $tag->name ); ?></a></span>
			</div>
	<div class="img-catlight"><?php echo do_action( 'taxonomy_image_plugin_print_image_html', 'detail' );?>
	</div>
	<?php $description = tag_description( '', get_query_var( 'post_tag' ) ); ?>
				<?php if ( !empty( $description ) ) echo '<span class="headlines">' . $description . '</span>'; ?>
		</div><!-- .yui-cms-item yui-panel -->	

	<?php  
	if ( current_theme_supports( 'popular-inthis' ) ) {
	include( trailingslashit( STYLESHEETPATH ) . 'library/extensions/popinthistag.php' );
	} ?>		

		<?php elseif ( is_search() ) : ?>
				<div class="breadcrumbs">
			<div class="hd"><strong><?php /* Search Count */ $allsearch = &new WP_Query("s=$s&showposts=-1"); $key = esc_html($s, 1); $count = $allsearch->post_count; _e(''); _e('Searched term: "<span class="gr" style="font-size:120%;">'); echo $key; _e('</span>"'); _e(' &mdash; '); echo $count . ' '; _e('articles'); wp_reset_query(); ?></strong>
			</div>
				<p><?php _e('Thanks for searching the', 'hybrid-news'); ?>
			<?php bloginfo('name'); ?> <?php _e('site.', 'hybrid-news'); ?> <?php _e('The main content area lists some results that we hope are the sorts of things you were looking for.', 'hybrid-news'); ?></p>

			</div><!-- .yui-cms-item yui-panel -->
			
		<?php elseif ( is_post_type_archive() ) : ?>
				
			<?php $post_type = get_post_type_object( get_query_var( 'post_type' ) ); ?>
				<div class="breadcrumbs">
			<div class="hd gr" style="font-size:120%;"><?php post_type_archive_title(); ?></div>
				<?php if ( !empty( $post_type->description ) ) echo "<p>{$post_type->description}</p>"; ?>
			</div><!-- .yui-cms-item yui-panel --> 
		
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('sidebar-archive') ) : 
	else : ?><?php endif; ?> 

	<?php elseif ( is_page() ) : ?>

	 <div class="breadcrumbs">
	  <div class="hd"><?php echo apply_atomic_shortcode( 'entry_utility', '<div class="entry-utility">' . __( '[entry-print-link] [entry-email-link] [entry-popup-shortlink]', hybrid_get_textdomain() ) . '</div>' ); ?>
	</div>
	<?php if ( post_type_exists( 'postnote' ) ) ?>
	<?php
	{ $postnote = get_post_meta
	($post->ID, 'postnote', $single = true); ?>
	<div class="breadcrumbs entry-postnote">
	<?php if($postnote !== '') echo $postnote; 
	else
	_e( 'No Editorial Note:', hybrid_get_textdomain() );
	} ?>
	</div><!-- entry-postnote-->
	<?php ?>
		<?php echo do_shortcode( '[entry-cakifo-twitter]' );?>
	<span class="date"><?php echo do_shortcode('[yui-news-source-meta before="News Source: "]'); ?></span>			

		</div><!-- .yui-cms-item yui-panel -->
	
	<div class="breadcrumbs">
	<?php global $notfound; ?>
	 <?php /* Creates a menu for pages beneath the level of the current page */
	  if (is_page() and ($notfound != '1')) {
	   $current_page = $post->ID;
	   while($current_page) {
		$page_query = $wpdb->get_row("SELECT ID, post_title, post_status, post_parent FROM $wpdb->posts WHERE ID = '$current_page'");
		$current_page = $page_query->post_parent;
	   }
	   $parent_id = $page_query->ID;
	   $parent_title = $page_query->post_title;
	if ($wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_parent = '$parent_id' AND post_status != 'attachment'")) { ?>
	<div class="hd"><span class="gr" style="font-size:120%;"><?php echo $parent_title; ?></span><br>
	<em><?php _e('has the following Subpages', hybrid_get_textdomain() ); ?></em></div>

		<ul class="listing"><span style="font-size:12px;color:#E76300;"><?php wp_list_pages('sort_column=menu_order&title_li=&child_of='. $parent_id); ?><span></ul>
		<?php if ($parent_id != $post->ID) { ?> 
		<br />
	 <li class="sidebarheader"><a href="<?php echo get_permalink($parent_id); ?>"><?php printf(__('Back to %s', 'hybrid'), $parent_title ) ?></a></li>
	  <?php } ?>  
	 <?php } } ?>
	  <?php echo do_shortcode( '[entry-subpage-excerpts]'), hybrid_get_textdomain(); ?>
	 </div>			
		
			<?php elseif ( is_date() || is_date () || is_tax || is_search()) : ?>
			<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('sidebar-archive') ) : else : ?><?php endif; ?> 
			
	 <?php endif; ?> 