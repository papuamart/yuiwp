<div class="yui-gd">			
<div class="yui-u first">			
	<?php get_sidebar( 'feature' ); ?>
</div>
	
	<div class="yui-u">			
<?php get_sidebar( 'home' ); // Loads the sidebar-primary.php template. ?>
			</div>
			</div>
			
			<div class="yui-gb">
<div class="yui-u first">	
 <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('home-middle-left') ) : else : ?>
	<div class="widget-top"><?php _e('Home Middle Left', hybrid_get_textdomain() ); ?></div>
	<div class="nowidget"><a href="<?php echo get_settings('home'); ?>/wp-admin/widgets.php/" target="_self" title="Click to add widgets">Add "Home Middle Left" Widgets</a></div>
	<div class="widget-bottom"></div>
<?php endif; ?>
</div>
<div class="yui-u">	
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('home-middle-right') ) : else : ?>
	<div class="widget-top"><?php _e('Home Middle Right', hybrid_get_textdomain() ); ?></div>
	<div class="nowidget"><a href="<?php echo get_settings('home'); ?>/wp-admin/widgets.php/" target="_self" title="Click to add widgets">Add "Home Middle Right" Widgets</a></div>
	<div class="widget-bottom"></div>
<?php endif; ?>
</div>

<div class="yui-u">	
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('home-bottom') ) : else : ?>
	<div class="widget-top"><?php _e('Home Bottom', hybrid_get_textdomain() ); ?></div>
	<div class="nowidget"><a href="<?php echo get_settings('home'); ?>/wp-admin/widgets.php/" target="_self" title="Click to add widgets">Add "Home Bottom" Widgets</a></div>
	<div class="widget-bottom"></div>
<?php endif; ?>
</div>
</div>