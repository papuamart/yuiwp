<?php
/**
 * Footer Template
 *
 * The footer template is generally used on every page of your site. Nearly all other
 * templates call it somewhere near the bottom of the file. It is used mostly as a closing
 * wrapper, which is opened with the header.php file. It also executes key functions needed
 * by the theme, child themes, and plugins. 
 *
 * @package Hybrid
 * @subpackage Template
 */
?>

<?php
/**
 * After Container Utility
 *
 * This template displays widgets for Utility: Before Content.
 * If no widgets are added, nothing is displayed.
 * @link http://themehybrid.com/themes/hybrid/widget-areas
 *
 * @package Hybrid
 * @subpackage Template
 */
?>
	</div><!-- .yui-u -->
		</div><!-- .yui-gd -->
		</div><!-- .yui-b -->
	</div><!-- #yui-main -->

	<div class="yui-b">		
 
<?php get_sidebar( 'primary' ); // Loads the sidebar-primary.php template. ?>
 
 </div><!-- .yui-b -->
	</div><!-- #container -->
	</section><!-- #container -->

	<footer id="footer-container">
	
		<?php do_atomic( 'before_footer' ); // hybrid_before_footer ?>

		<div id="ft">


		<div id="footer">

			<?php do_atomic( 'footer' ); // hybrid_footer ?>

		</div><!-- #footer -->


	</div><!-- #footer-container -->
	
		<?php do_atomic( 'after_footer' ); // hybrid_after_footer ?>

		</footer><!-- #footer-container -->

</div><!-- #body-container -->

<?php if (current_theme_supports( 'dispatch-multicolour' ) ) {
echo '</div><!-- close dispatch colour css div -->';
	} ?>
	<?php if (is_home() && !is_paged() && current_theme_supports( 'news-ticker' ) ) { include ( 'library/content/home-news-ticker.php' ); } ?>

<?php do_atomic( 'after_html' ); // hybrid_after_html ?>

<?php wp_footer(); // wp_footer ?>
<script type="text/javascript">
//var oTabView = new YAHOO.widget.TabView("customPostsTypeTabview");
//var oTabView = new YAHOO.widget.TabView("archivePageTabview");
var oTabView = new YAHOO.widget.TabView("sidebarSlideShowTabView");
var oTabView = new YAHOO.widget.TabView("FeaturedCatsTabView");
var oTabView = new YAHOO.widget.TabView("SelectedCatsTabView");
var oTabView = new YAHOO.widget.TabView("recentUpdatesTabview");
var oTabView = new YAHOO.widget.TabView("popstabview");
var oTabView = new YAHOO.widget.TabView("elpopTabView");
var oTabView = new YAHOO.widget.TabView("archivecontenttabview");
var oTabView = new YAHOO.widget.TabView("homTestTabView");
</script>
</body>
</html>