<?php
/**
 * Video Sidebar Template
 *
 * @package News
 * @subpackage Template
 * @since 0.1.0
 * @deprecated 0.3.0 Please include this template in your child theme if you plan to continue using it.
 */

/* Deprecated file in version 0.3.0. */
_deprecated_file( basename( __FILE__ ), '0.3.0', null, sprintf( __( 'Please copy the %s template from this theme into your child theme folder.', 'hybrid-child' ), basename( __FILE__ ) ) );

if ( is_active_sidebar( 'video' ) ) : ?>

	<div id="sidebar-video" class="sidebar utility">

		<?php dynamic_sidebar( 'video' ); ?>

	</div><!-- #sidebar-video .utility -->

<?php else : ?>

	<div id="sidebar-video" class="sidebar utility">

	<div id="sidebarVideoTabView" class="yui-navset">	

			<ul class="yui-nav">
					<li class="selected"><a href="#video-tabs-1"><em><?php _e( 'Recent', 'hybrid-child' ); ?></em></a></li>
					<li><a href="#video-tabs-2"><em><?php _e( 'Popular', 'hybrid-child' ); ?></em></a></li>
					<li><a href="#video-tabs-3"><em><?php _e( 'Gallery', 'hybrid-child' ); ?></em></a></li>
				</ul><!-- .ui-tabs-nav -->	
	
			<div class="yui-content">

				<div id="video-tabs-1" class="ui-tabs-panel">

					<?php $loop = new WP_Query( array( 'post_type' => apply_filters( 'news_video_post_type', 'video' ), 'posts_per_page' => 3 ) ); ?>

					<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

						<div class="<?php hybrid_entry_class(); ?>">

							<?php get_the_image( array( 'meta_key' => array( 'Thumbnail' ), 'size' => 'news-thumbnail' ) ); ?>

							<?php echo apply_atomic_shortcode( 'entry_title', the_title( '<h4 class="entry-title"><a href="' . get_permalink() . '" title="' . the_title_attribute( 'echo=0' ) . '" rel="bookmark">', '</a></h4>', false ) ); ?>

							<?php echo apply_atomic_shortcode( 'byline', '<div class="byline">[entry-published]</div>' ); ?>

						</div><!-- .hentry -->

					<?php endwhile; ?>

				</div><!-- .ui-tabs-panel -->

				<div id="video-tabs-2" class="ui-tabs-panel">

					<?php $loop = new WP_Query( array( 'post_type' => apply_filters( 'news_video_post_type', 'video' ), 'orderby' => 'comment_count', 'posts_per_page' => 3 ) ); ?>

					<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

						<div class="<?php hybrid_entry_class(); ?>">

							<?php get_the_image( array( 'meta_key' => array( 'Thumbnail' ), 'size' => 'news-thumbnail' ) ); ?>

							<?php echo apply_atomic_shortcode( 'entry_title', the_title( '<h4 class="entry-title"><a href="' . get_permalink() . '" title="' . the_title_attribute( 'echo=0' ) . '" rel="bookmark">', '</a></h4>', false ) ); ?>

							<?php echo apply_atomic_shortcode( 'byline', '<div class="byline">[entry-published]</div>' ); ?>

						</div><!-- .hentry -->

					<?php endwhile; ?>

				</div><!-- .ui-tabs-panel -->
				
					
				<div id="video-tabs-3" class="ui-tabs-panel">
				
				<?php the_widget( 'News_Widget_Image_Stream' ); ?> 

				</div><!-- #slideshow-tabs-3 .ui-tabs-panel -->
		

			</div><!-- .ui-tabs-wrap -->

		</div><!-- .ui-tabs -->

		<?php wp_reset_query(); ?>
	<script type="text/javascript" charset="utf-8">
	var oTabView = new YAHOO.widget.TabView("sidebarVideoTabView");
	</script>
	</div><!-- #sidebar-video .utility -->

<?php endif; ?>