var Dom = YAHOO.util.Dom;
var Event = YAHOO.util.Event;

YAHOO.namespace("snippet");
YAHOO.snippet.ticker = {
	init : function(className){
		this.speed = 135;
		// get all ticker element from a page
		this.tickerEl = Dom.getElementsByClassName(className);
		for(var i=0; i<this.tickerEl.length; i++) {
			this.buildTicker(this.tickerEl[i]);
		}
	},
	buildTicker : function(tickerEl) {
		// get all newsitems from a ticker element
		this.tickerItem = tickerEl.getElementsByTagName("li");
		this.tickerItemContainer = tickerEl.getElementsByTagName("ul");

		// get width of all list items and set the container to this width
		this.containerWidth = 0;
		for(var i=0; i<this.tickerItem.length; i++) {
			this.containerWidth += Dom.getRegion(this.tickerItem[i]).right - Dom.getRegion(this.tickerItem[i]).left;
		}
		Dom.setStyle(this.tickerItemContainer[0],"width",this.containerWidth + "px");

		// set position of container to the left of the containing box
		Dom.setStyle(this.tickerItemContainer[0],"left", (Dom.getRegion(tickerEl).right - Dom.getRegion(tickerEl).left) + "px");
		this.yPos = Dom.getRegion(this.tickerItemContainer[0]).top;

		// set listener for mouseover
		Event.addListener(this.tickerItemContainer[0],"mouseover",this.pauseAnim,this);

		// set listener for mouseout
		Event.addListener(this.tickerItemContainer[0],"mouseout",this.restartAnim,this);

		// start animation
		this.startAnim();
	},
	startAnim : function() {
		this.attributes = {
			points: { to: [-this.containerWidth,this.yPos] }
		};
		this.anim = new YAHOO.util.Motion(this.tickerItemContainer[0], this.attributes);
		this.startPos = Dom.getStyle(this.tickerItemContainer[0],"left");
		this.startPos = this.startPos.split("px")[0];
		this.currentWidth = this.containerWidth + parseFloat(this.startPos);
		this.anim.duration = this.currentWidth/this.speed;
		this.anim.useSeconds = true;
		this.anim.onComplete.subscribe(this.endAnim,this);
		this.anim.animate();
	},
	pauseAnim : function(e,obj) {
		obj.anim.stop();
	},
	restartAnim : function(e,obj) {
		obj.currentWidth = obj.containerWidth + Dom.getRegion(obj.tickerItemContainer[0]).left;
		obj.anim.duration = obj.currentWidth/obj.speed;
		obj.anim.animate();
	},
	endAnim : function(state,dur,obj) {
		if(Dom.getRegion(obj.tickerItemContainer[0]).left <= -obj.containerWidth) {
			YAHOO.snippet.ticker.init("newsTicker");
		};
	}
}

initPage = function() {
	YAHOO.snippet.ticker.init("newsTicker");
}

Event.on(window,"load",initPage);