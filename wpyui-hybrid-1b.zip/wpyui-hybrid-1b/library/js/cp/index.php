<?php
/*
* silense is gold 
*******************

/* Simplicity is perfection 
*******************
*/
?>