/* Simple sandbox resize content (March 11th, 10)
* This notice must stay intact for usage 
* Author: Dynamic Drive at http://www.dynamicdrive.com/
* Visit http://www.dynamicdrive.com/ for full source code
*/

// v3.0 (April 25th, 2013)
YUI({filter: 'raw'}).use('resize', function(Y) {

	var r1 = new Y.Resize({
		node: '#r1'
	});

	var r2 = new Y.Resize({
		node: '#r2'
	});

	r2.plug(Y.Plugin.ResizeConstrained, {
		tickX: 20,
		tickY: 20,
		minWidth: 50,
		minHeight: 50,
		maxWidth: 300,
		maxHeight: 300,
		preserveRatio: true
	});

	var r3 = new Y.Resize({
		node: '#r3',
		wrap: true
	});

	r3.plug(Y.Plugin.ResizeProxy, {
		// proxyNode: Y.Node.create('<div class="aui-proxy"></div>')
	});

	var r4 = new Y.Resize({
		node: '#r4',
		autoHide: true
	})
	.plug(Y.Plugin.ResizeProxy);

	var r5 = new Y.Resize({
		node: '#r5',
		autoHide: true
	})
	.plug(Y.Plugin.ResizeProxy);

	var r6 = new Y.Resize({
		node: '#r6'
	});

	r6.plug(Y.Plugin.ResizeConstrained, {
		preserveRatio: true
	});

	var r7 = new Y.Resize({
		node: '#r7'
	});

	// r7.on('resize', function(event) {
	// 	console.log( event.currentTarget.get('activeHandle') );
	// });

	r7.plug(Y.Plugin.ResizeConstrained, {
		constrain: '#r7Container',
		// preserveRatio: true,
		minHeight: 50,
		minWidth: 50
	});

    var boxSurroundingResize1 = new Y.Resize({
        node: '#boxSurroundingDemo1'
    });

	boxSurroundingResize1.plug(Y.Plugin.ResizeConstrained, {
		constrain: '#boxSurroundingWrapper1'
	});

    var boxSurroundingResize2 = new Y.Resize({
        node: '#boxSurroundingDemo2'
    });

    var boxSurroundingResize3 = new Y.Resize({
        node: '#boxSurroundingDemo3',
		wrap: true
    });

    var boxSurroundingResize4 = new Y.Resize({
        node: '#boxSurroundingDemo4',
			wrap: true
    });

	boxSurroundingResize4.plug(Y.Plugin.ResizeProxy);

	Y.one('#r3btn').on('click', function() { r3.destroy(); });
});