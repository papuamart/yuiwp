<?php

/* Register custom post types. */
	add_action( 'init', 'news_register_post_formats_styles' );
/**
 * Registers custom post types for the theme.  We're registering the Video and Slideshow post types.
 *
 * Important!  This will be removed in a future version and placed in an external plugin.
 *
 * @since 0.1.0
 */
function news_register_post_formats_styles() {

	$domain = hybrid_get_textdomain();
	$prefix = hybrid_get_prefix();
// Using Formats
if ( has_post_format( 'aside' )) {
  // code to display the aside format post here
} elseif (has_post_format('gallery')) {
   // stuff to display the gallery format post here
} elseif (has_post_format('link')) {
  // stuff to display the gallery format post here
} elseif (has_post_format('video')) {
   // stuff to display the link format post here
}else {
   // code to display the normal format post here
}
}
?>