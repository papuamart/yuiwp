<?php 

/* The following code was written exclusively for MOJO-Themes.com
   Use at your own discretion and free will.
   Author: Brady Nord ( www.bradynord.com, @bradynord )
   Version: 1.0 - 11/18/2010
      

/* ----------------------------------------------------------------- */
/* ---------------------- Boxes No Icons --------------------------- */
/* ----------------------------------------------------------------- */


/* ------- Boxes - Alert ( Yellow ) --------*/
function alertbox($atts, $content=null, $code="") {  
	
	$return = '<div class="alert">';
	
	$return .= $content;
	
	$return .= '</div>';
	
	return $return;

}
add_shortcode('alert' , 'alertbox' );

/* ------- Boxes - News ( Grey ) --------*/

function newsbox($atts, $content=null, $code="") {  
	$return = '<div class="news">';	
	$return .= $content;	
	$return .= '</div>';	
	return $return;
}
add_shortcode('news' , 'newsbox' );


/* ------- Boxes - Info ( Blue ) --------*/
function infobox($atts, $content=null, $code="") {  
	$return = '<div class="info">';
	$return .= $content;	
	$return .= '</div>';	
	return $return;
}
add_shortcode('info' , 'infobox' );


/* ------- Boxes - Warning ( Red ) --------*/
function warningbox($atts, $content=null, $code="") { 
	$return = '<div class="warning">';	
	$return .= $content;	
	$return .= '</div>';
	return $return;
}
add_shortcode('warning' , 'warningbox' );


/* ------- Boxes - Download ( Green ) --------*/
function downloadbox($atts, $content=null, $code="") {  
	$return = '<div class="download">';	
	$return .= $content;
	$return .= '</div>';	
	return $return;
}
add_shortcode('download' , 'downloadbox' );

/* ----------------------------------------------------------------- */
/* ------------------------- Drop Caps ----------------------------- */
/* ----------------------------------------------------------------- */

/* ------- Drop Cap Small --------*/

function dropcap($atts, $content=null, $code="") {  
	$return = '<div class="dropcap-small">';
	$return .= $content;	
	$return .= '</div>';	
	return $return;
}
add_shortcode('dropcap-small' , 'dropcap' );

/* ------- Drop Cap Large --------*/

function dropcap2($atts, $content=null, $code="") { 
	$return = '<div class="dropcap-big">';
	$return .= $content;	
	$return .= '</div>';	
	return $return;
}
add_shortcode('dropcap-big' , 'dropcap2' );

/* ----------------------------------------------------------------- */
/* ------------------------ Sticky Notes --------------------------- */
/* ----------------------------------------------------------------- */

/* ------- Sticky Note Left Aligned --------*/
function stickyleft($atts, $content=null, $code="") {  
	$return = '<div class="stickyleft">';	
	$return .= $content;	
	$return .= '</div>'; 	
	return $return;
}
add_shortcode('stickyleft' , 'stickyleft' );

/* ------- Sticky Note Right Aligned --------*/

function stickyright($atts, $content=null, $code="") {  
	$return = '<div class="stickyright">';	
	$return .= $content;	
	$return .= '</div>';	
	return $return;
}
add_shortcode('stickyright' , 'stickyright' );

/* ----------------------------------------------------------------- */
/* -------------------------- Columns ------------------------------ */
/* ----------------------------------------------------------------- */


/* ------- 1/2 --------*/
function one_half( $atts, $content = null ) {   
   return '<div class="one_half">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_half', 'one_half');

function one_half_last( $atts, $content = null ) {   
   return '<div class="one_half last">' . do_shortcode($content) . '</div>   
   <div class="clearboth"></div>';
}
add_shortcode('one_half_last', 'one_half_last');


/* ------- 1/3 --------*/

function one_third( $atts, $content = null ) {   
   return '<div class="one_third">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_third', 'one_third');

function one_third_last( $atts, $content = null ) {   
   return '<div class="one_third last">' . do_shortcode($content) . '</div>   
   <div class="clearboth"></div>';
}
add_shortcode('one_third_last', 'one_third_last');


/* ------- 1/4 --------*/
function one_fourth( $atts, $content = null ) {   
   return '<div class="one_fourth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_fourth', 'one_fourth');

function one_fourth_last( $atts, $content = null ) {   
   return '<div class="one_fourth last">' . do_shortcode($content) . '</div>   
   <div class="clearboth"></div>';
}
add_shortcode('one_fourth_last', 'one_fourth_last');

function cornered_textbox_inside( $atts, $content = null ) {?>
	<div class="top-left"></div><div class="top-right"></div>
		<div class="inside">
<?php return '<p class="notopgap">' . do_shortcode($content) . '</p>'; ?>
		<p class="nobottomgap">.</p>
		</div>
	<div class="bottom-left"></div><div class="bottom-right"></div>
<?php 
}
add_shortcode('cornered_textbox_inside', 'cornered_textbox_inside');
?>