<?php
/**
 * Home News Ticker Template
 *
 * Displays information at the top of the page about archive and search results when viewing those pages.  
 * This is not shown on the home page and singular views.
 *
 * @package News
 * @subpackage Template
 */
?>
<div class="newsTicker">
<?php $getposts = new WP_query(); $getposts->query('showposts=5&cat=10,11,31&offset=4&cat='.$section); ?>
	<?php global $wp_query; $wp_query->in_the_loop = true; ?>
	<?php while ($getposts->have_posts()) : $getposts->the_post(); ?>
<ul>
<li><span class="description"><a target="_self" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>,&nbsp;<span class="timestamp "><?php the_time('j F, Y') ?>, <?php the_time('g:i a') ?>&lrm;</span>&nbsp,&nbsp;<?php printf( __('dalam: %s', 'yahoowp'), get_the_category_list(', ') ) ?>
</span></li><?php endwhile; ?>
  </ul>
</div>	
<style type="text/css">
div.newsTicker {
 position: relative;
 width: 100%;
 overflow: hidden;
 background-color:#fefefe;
 margin-top:1px;border-bottom:1px dotted #ccc;
}
div.newsTicker ul li {
 white-space: nowrap;
 float: left;
 list-style-type:circle;border-right:1px dotted #ccc;
 padding-right: 30px; /* don't change to margin = margin between news items */
}
</style>
<script src="<?php bloginfo('stylesheet_directory'); ?>/library/js/newsticker.js" type="text/javascript">