<?php
/**
 * Additional shortcodes for use within the theme.
 *
 * @package News
 * @subpackage Functions
 */
	/* Register sidebars. */
	add_action( 'init', 'yui_news_register_shortcodes', 11 );
/**
 * Registers new shortcodes.
 * 	PMNews Added SHORTCODES for main entry manipulation  

 * @since 0.1.0
 */
function yui_news_register_shortcodes() {
	
	add_shortcode( 'slideshow', 'yui_news_slideshow_shortcode' );
	add_shortcode( 'entry-popup-shortlink', 'yui_news_entry_shortlink_popup_shortcode' );
	add_shortcode( 'entry-print-link', 'yui_news_entry_print_link_shortcode' );
	add_shortcode( 'entry-email-link', 'yui_news_entry_email_link_shortcode' );
	add_shortcode( 'entry-mixx-link', 'yui_news_entry_mixx_link_shortcode' );
	add_shortcode( 'entry-delicious-link', 'yui_news_entry_delicious_link_shortcode' );
	add_shortcode( 'entry-digg-link', 'yui_news_entry_digg_link_shortcode' );
	add_shortcode( 'entry-facebook-link', 'yui_news_entry_facebook_link_shortcode' );
	add_shortcode( 'entry-twitter-link', 'yui_news_entry_twitter_link_shortcode' );

	add_shortcode( 'yui-news-site-description', 'yui_news_site_descriptions_shortcode' );
	add_shortcode( 'entry-sidebar-pagination', 'yui_news_sidebar_pagination_shortcode' );	
	
	add_shortcode( 'entry-google-breadcrumb', 'yui_news_google_breadcrumb_menu_shortcode' );
	add_shortcode( 'entry-tags-breadcrumb', 'yui_news_entry_tags_breadcrumb_shortcode' );
	add_shortcode( 'entry-meta-breadcrumb', 'yui_news_entry_meta_breadcrumb_shortcode' );
	
	add_shortcode( 'entry-subtitle', 'yui_news_entry_subtitle_shortcode' );
	add_shortcode( 'entry-postnote', 'yui_news_entry_postnote_shortcode' );
	add_shortcode( 'entry-published', 'yui_news_entry_published_link_shortcode' );
	add_shortcode('posted-time-ago', 'yui_news_posted_time_ago_shortcode');
	
	add_shortcode('widget','widget'); // registers the shortcode
	add_shortcode('query', 'query_posts_shortcode'); // add the shortcode...
	add_shortcode( 'show_file', 'show_file_func' );
	add_shortcode('permalink', 'do_permalink');

	// special hacks to display news from special dates
	add_shortcode('two-thousand-posts', 'two_thousand_dates_posts_shortcode');	
	add_shortcode('sixties-posts', 'sixties_dates_posts');
	add_shortcode('seventies-posts', 'seventies_dates_posts');
	
	add_shortcode( 'the-year', 'hybrid_the_years_shortcode' );
	add_shortcode('last-modified', 'last_modified_posts_shortcode');	
	add_shortcode( 'yui-news-source-meta', 'yui_news_source_meta_shortcode' );
//	
	add_shortcode( 'entry-stumbleupon-link', 'yui_news_entry_stumbleupon_link_shortcode' );
	add_shortcode( 'entry-stumbleupon-count', 'yui_news_entry_stumbleupon_counts_shortcode' );	

	// PMNews Additional shortcodes for social-bookmarking/ share news
	add_shortcode( 'entry-googleplus-link', 'cakifo_entry_googleplus_link_shortcode' );
	
	add_shortcode( 'entry-technocrati-link', 'yui_news_entry_technocrati_link_shortcode' );
	add_shortcode( 'entry-sphere-link', 'yui_news_entry_sphere_link_shortcode' );
	add_shortcode( 'entry-excite-link', 'yui_news_entry_excite_link_shortcode' );
	add_shortcode( 'entry-sharemore-link', 'yui_news_entry_sharemore_link_shortcode' );
	//
	add_shortcode( 'entry-tags-with-count', 'yui_news_entry_tag_with_count_shortcode' );
	add_shortcode( 'entry-category-with-count', 'yui_news_entry_category_with_count_shortcode' );
	add_shortcode( 'entry-cats-with-count', 'yui_news_entry_cats_with_count_shortcode' );
	add_shortcode( 'entry-words-count', 'yui_news_entry_word_count_shortcode' );
	add_shortcode( 'entry-post-count', 'yui_news_entry_post_count_shortcode' );
	add_shortcode( 'entry-font-size', 'yui_news_entry_font_size_shortcode' );
	add_shortcode( 'home-share-link', 'yui_news_home_share_link_shortcode' );
	add_shortcode( 'single-share-link', 'yui_news_entry_share_link_shortcode' );
	add_shortcode( 'comment-count', 'yui_news_comment_count_shortcode' );	
	add_shortcode( 'entry-pdf-link', 'yui_news_entry_pdf_link_shortcode');
	add_shortcode( 'entry-flickr-share', 'yui_news_entry_flickr_share_shortcode');
	add_shortcode('pdf', 'pdflink');
	
	// SHARE BUTTONS WITH COUNT
	add_shortcode( 'entry-linkedin-link', 'yui_news_entry_linkedin_link_shortcode' );
	add_shortcode( 'entry-reddit-count', 'yui_news_entry_reddit_count_shortcode' );
	add_shortcode( 'entry-fblike-live-link', 'yui_news_entry_fblike_live_link_shortcode' );
	add_shortcode( 'tweets-counts', 'yui_news_entry_tweet_counts_link_shortcode' );
	add_shortcode( 'tweets-small-counts', 'yui_news_entry_small_tweetme_count_link_shortcode' );
	add_shortcode( 'entry-gbuzz-counts', 'yui_news_entry_gbuzz_counts_shortcode' );
	add_shortcode( 'entry-digg-counts', 'yui_news_entry_digg_counts_link_shortcode' );
//
	add_shortcode( 'cakifo-twitter-username', 'cakifo_twitter_shortcode' );
	add_shortcode( 'entry-cakifo-twitter', 'cakifo_entry_twitter_link_shortcode' );
	add_shortcode( 'cakifo-entry-format', 'cakifo_entry_format_shortcode' );
	add_shortcode( 'cakifo-entry-type', 'cakifo_entry_type_shortcode' );

	/* the shortcodes from functions i "entries.php" */
	add_shortcode('recent-posts', 'yui_news_recent_posts_shortcode'); // refer to pm-recents.html
	add_shortcode('recent-updated', 'recently_updated_posts_shortcode'); // refer to pm-recents.html
	add_shortcode('recent-comments', 'recent_comments_shortcode');  // refer to pm-recents.html
	add_shortcode('home-archive-content', 'yui_news_home_archive_content_shortcode');  // this is only useful for front-page.php or home.php archieve articles
add_shortcode( 'print-title', 'print_title' );add_shortcode( 'short-title', 'short_title' );
add_shortcode( 'print-archive-title', 'print_archive_title' );
add_shortcode( 'subheader-loop-meta', 'yui_news_subheader_loop_meta' );
add_shortcode('entry-subpage-excerpts', 'yui_news_subpage_excerpts_shortcode');
add_shortcode('site-user-login', 'yui_news_login_logout_shortcode');
}
function yui_news_login_logout_shortcode( ) { ?>
		<!-- USER AND WEB ADMIN -->
	<?php _e('You are Very Welcome', hybrid_get_textdomain() ); ?>		
   <?php global $user_ID; if( $user_ID ) : ?>
	<?php if(current_user_can('level_10')) : ?>
	&nbsp;"<strong><?php user_info('user_email'); ?></strong>"
	<?php wp_register("","<span class='vsep cms-dynamic'></span>"); ?>
	<?php endif; ?>
	<?php else : ?>
	<?php _e( 'Guest!', hybrid_get_textdomain() ); ?> 
	<?php endif; ?><!-- USER AND WEB ADMIN -->
<?php 
}

function yui_news_entry_tags_breadcrumb_shortcode() {
echo '<div class="tagsbreadcrumb"><span class="tagsheading">';
//if (is_singular()) if ( current_theme_supports( 'get-the-image' ) ) get_the_image( array( 'custom_key' => false, 'the_post_thumbnail' => false, 'default_size' => 'thumbnail', 'image_scan' => true, 'width' => '125', 'default_image' => './wp-content/uploads/images/default_thumb.gif' ) ); 
if ( is_home() || is_front_page() || is_page_template('page-home.php') || is_page_template('page-front-page.php') || is_page_template('page-news-front-page.php')) :
	echo do_shortcode('[site-user-login]');
	 elseif ( is_category() ) :
		//echo do_action( 'taxonomy_image_plugin_print_image_html', 'detail' );
		echo single_cat_title();
	elseif ( is_tag() ) : 
	//	echo do_action( 'taxonomy_image_plugin_print_image_html', 'detail' ); 
		echo single_tag_title();
	elseif ( is_archive() ) : 
		echo 'Archives:&nbsp;'; echo wp_title();	
	elseif ( is_attachment() ) : 
		echo 'Image:&nbsp;'; echo the_ID();
	elseif ( is_singular('post') ) :
		echo tagAndCatBreadCrumb(); 
	elseif ( is_search() ) : 
		echo esc_attr( get_search_query() );  
	elseif ( is_date() ) :	
		echo 'Archives:&nbsp;'; echo wp_title();	
	elseif ( is_page() ) : 
	//	echo do_action( 'taxonomy_image_plugin_print_image_html', 'detail' ); 
		 echo wp_title(); echo tagAndCatBreadCrumb(); 
	elseif ( is_author() ) :
		the_author_meta( 'display_name', $id ); 
	elseif (array( 'post_type') ) :
	$posttype = get_post_type( $post->ID ); if ( $posttype) { echo '(' . $posttype . 's)'; }
	echo tagAndCatBreadCrumb(); 	
	 endif; 	
echo '</span></div>';
 global $page, $paged;
 echo '<span class="newspaper2">';
	// Add a page number if necessary: 
	if ( $paged >= 2 || $page >= 2 ) echo '&nbsp;|&nbsp;' . sprintf( __( 'Page %s', 'hybrid-yui-news' ), max( $paged, $page ) );
echo '</span><br clear="all">'; 

if ( is_home() && is_front_page() ) :
echo '<div class="googlebreadcrumb">'; echo googleBreadcrumbs(); echo '</div>';
elseif ( is_archive() ) :
echo '<div class="googlebreadcrumb">'; echo googleBreadcrumbs(); echo '</div>';
elseif ( is_search() ) :
echo '<div class="googlebreadcrumb">'; echo googleBreadcrumbs(); echo '</div>';
elseif ( is_singular() ) :
echo the_ID(); echo'&nbsp;&raquo;&nbsp;'; echo do_shortcode('[entry-words-count] [entry-views before=" Views: "]'); 
elseif ( is_page('Custom Posts') ) :
echo '<div class="googlebreadcrumb">'; echo googleBreadcrumbs(); echo '</div>';
endif; 	
}

function yui_news_sidebar_pagination_shortcode() {
 global $page, $paged;
 echo '<span class="newspaper2">';
	// Add a page number if necessary: 
	if ( $paged >= 2 || $page >= 2 ) echo '&nbsp;|&nbsp;' . sprintf( __( 'Page %s', 'hybrid-yui-news' ), max( $paged, $page ) );
echo '</span>'; 
}
function yui_news_site_descriptions_shortcode() {
echo '<div class="feat-tags">';
	if (is_home() || is_front_page() || is_page_template('page-front-page.php') || is_page_template('page-home.php')) 
		echo total_posts(); echo '&nbsp;posts&nbsp;<br/>'; 
		echo total_comments(); echo '&nbsp;comments&nbsp;<br />'; 
		echo do_shortcode('[query-counter]');
	if (is_category()) echo category_description();
	if (is_tag()) echo tag_description();
	if (is_tax()) single_term_title();  
	if (is_date()) wp_title();
	if (is_author()) the_author_meta( 'user_nicename', $id );
	if (is_attachment()) wp_title(); echo do_shortcode( '[entry-postnote]' );
	if(is_singular('faq')) { echo 'Frequenty Asked Questions and Answers';}
	if(is_singular('post')) echo do_shortcode( '[entry-postnote]' );
	if(is_page()) echo do_shortcode( '[entry-postnote]' );
echo '</div>';		
}

// yui_news_subpage_excerpts_shortcode
if ( ! function_exists( 'yui_news_subpage_excerpts_shortcode' ) ) :

//add_shortcode('query', 'query_posts_shortcode'); // add the shortcode...
function yui_news_subpage_excerpts_shortcode() {
global $post;
	
	//query subpages
	$args = array(
		'post_parent' => $post->ID,
		'post_type' => 'page'
	);
	$subpages = new WP_query($args);
	
	// create output
	if ($subpages->have_posts()) : 
		$output = '<ol class=listing style="margin-left:-5px;">';
		while ($subpages->have_posts()) : $subpages->the_post();
			$output .= '<div class=comment-text style=clear:both;><li><strong><a href="'.get_permalink().'">'.get_the_title().'</a></strong>
						<p>'.get_the_excerpt().'<br />
						<a href="'.get_permalink().'">Continue Reading &rarr;</a></p></li></div>';
		endwhile;
		$output .= '</ol>';
	else :
		$output = '<p>No subpages found.</p>';
	endif;
	
	// reset the query
	wp_reset_postdata();
	
	// return something
	return $output; 
}
  // turn the function into a shortcode
//add_shortcode('entry-subpage-excerpts', 'yui_news_subpage_excerpts_shortcode');
endif;
 
function yui_news_posted_time_ago_shortcode() { 
echo '<span class="postDate">';
echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . __( '&nbspago&nbsp-', 'hybrid-yui-news' );
echo '</span>';
}

// Post last modified
function last_modified_posts_shortcode($atts){
$u_time = get_the_time('U');
          $u_modified_time = get_the_modified_time('U');
      if ($u_modified_time != $u_time) {
                echo ",&nbsp;and modified on ";
                the_modified_time('F jS, Y');
                echo ".";
          }
}

//PMNEWS HACKS FOR MORE BEFORE AND AFTER CONTENT/ ENTRY
/*
* From this original edited into shortcode
<?php if($subtitle !=='') { ?>
<?php $values = get_post_custom_values("subtitle");
 echo $values[0]; ?><?php } ?>
*/
function yui_news_entry_subtitle_shortcode() {
	global $post;	
	$subtitle = get_post_meta
($post->ID, 'subtitle', $single = true);
if($subtitle !== '') echo '- ' . $subtitle;
}

function yui_news_entry_postnote_shortcode() {
	global $post;
	$postnote = get_post_meta
($post->ID, 'postnote', $single = true);
if($postnote !== '') echo '- ' . $postnote;
}

function yui_news_entry_cats_with_count_shortcode() {
	echo cats_with_count( '', __( '<span class="meta-sep">&para;</span>' , 'hybrid-yui-news' ) .' ', ', ', '' );
}
//add_shortcode('entry-cats-with-count', 'yui_news_entry_cats_with_count_shortcode');

// yui_news_entry_tag_with_count_shortcode()
function yui_news_entry_tag_with_count_shortcode() {
	echo tags_with_count( '', __( '<span class=tag-links meta-sep>&nbsp;&Dagger;</span>' , 'hybrid-yui-news' ) .' ', ', ', '' );
}

// A Flickr Badge using WordPress Shortcodes
function yui_news_entry_flickr_share_shortcode() {
echo '<div class="flickr_badge"><script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=5&display=latest&size=m&layout=h&source=all_tag&tag=papua,west papua,irian,new guinea"></script></div>';
}


function yui_news_entry_word_count_shortcode() {
echo '&nbsp;Length:&nbsp;['; 
echo word_count(); 
echo ']&nbsp;words.';
}

//add_shortcode('entry-word-count', 'yui_news_entry_word_count_shortcode');

function yui_news_entry_post_count_shortcode() {
echo '&nbsp;['; the_author_posts();
echo '&nbsp;&nbsp;entries]&nbsp;'; 
}
//add_shortcode('entry-word-count', 'yui_news_entry_word_count_shortcode');

// yui_news_entry_category_with_count_shortcode()
function yui_news_entry_category_with_count_shortcode() {
echo '<span class="cat-links"></span>'; the_category(', ');
echo '&#91;'; 
echo wt_get_category_count(); 
echo '&#93;';
}
//add_shortcode('entry-category-with-count', 'yui_news_entry_category_with_count_shortcode');
function yui_news_entry_published_link_shortcode() {
	/* Get the year, month, and day of the current post. */
	$year = get_the_time( 'Y' );
	$month = get_the_time( 'm' );
	$day = get_the_time( 'd' );
	$out = '';
	/* Add a link to the monthly archive. */
	$out .= '<a class="postDate" href="' . get_month_link( $year, $month ) . '" title="Archive for ' . esc_attr( get_the_time( 'F Y' ) ) . '">' . get_the_time( 'F' ) . '</a>';
	/* Add a link to the daily archive. */
	$out .= ' <a href="' . get_day_link( $year, $month, $day ) . '" title="Archive for ' . esc_attr( get_the_time( 'F d, Y' ) ) . '">' . $day . '</a>';
	/* Add a link to the yearly archive. */
	$out .= ', <a href="' . get_year_link( $year ) . '" title="Archive for ' . esc_attr( $year ) . '">' . $year . '</a>';
	return $out;
};

function hybrid_the_years_shortcode() {
global $wpdb;
$copyright_dates = $wpdb->get_results("
SELECT
YEAR(min(post_date_gmt)) AS firstdate,
YEAR(max(post_date_gmt)) AS lastdate
FROM
$wpdb->posts
WHERE
post_status = 'publish'
");
$output = '';
if($copyright_dates) {
$copyright = " " . $copyright_dates[0]->firstdate;
if($copyright_dates[0]->firstdate != $copyright_dates[0]->lastdate) {
$copyright .= '-' . $copyright_dates[0]->lastdate;
}
$output = $copyright;
}
return $output;
}
function yui_news_entry_font_size_shortcode() {
return '<span style="letter-spacing:-1px;"><a class="largeview" id="link-large-font" title="Click to Enlarge Font Size" href="javascript:increaseFontSize();">A</a><span class="vsep cms-dynamic"></span>
		<a class="normalviewt" id="link-normal-font" title="Click for Normal Font Size" href="javascript:normalFontSize();" >A</a><span class="vsep cms-dynamic"></span>
		<a class="xsmallview" id="link-small-font" title="Click to Minimize Font Size" href="javascript:decreaseFontSize();" >A</a>
</span>';
}

function yui_news_entry_meta_breadcrumb_shortcode() {?>
	
<?php if ( ( is_home() && ! is_front_page() ) ) : ?>

	<div class="loop-meta-home">

		<h3 class="loop-title"><?php echo get_post_field( 'post_title', get_queried_object_id() ); ?></h3>

		<div class="loop-description">
			<?php echo apply_filters( 'the_excerpt', get_post_field( 'post_excerpt', get_queried_object_id() ) ); ?>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta-home -->

<?php elseif ( is_category() ) : ?>

	<div class="loop-meta-tag">

		<h3 class="loop-title"><?php printf( __( 'Category Archives: %s', 'cakifo' ), '<span>' . single_cat_title( '', false ) . '</span>' ); ?></h3>

		<div class="loop-description">
			<?php echo category_description(); ?>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta -->

<?php elseif ( is_tag() ) : ?>

	<div class="loop-meta-tag">

		<h3 class="loop-title"><?php printf( __( 'Tag Archives: %s', 'cakifo' ), '<span>' . single_tag_title( '', false ) . '</span>' ); ?></h3>

		<div class="loop-description">
			<?php echo tag_description(); ?>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta -->

<?php elseif ( is_tax( 'post_format' ) ) : ?>

	<div class="loop-meta-tag">

		<h3 class="loop-title"><?php single_term_title(); ?></h3>

		<div class="loop-description">
			<?php echo term_description( '', get_query_var( 'taxonomy' ) ); ?>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta -->

<?php elseif ( is_tax() ) : ?>

	<div class="loop-meta-tag">

		<h3 class="loop-title"><?php printf( __( 'Archives: %s', 'cakifo' ), '<span>' . single_term_title( '', false ) . '</span>' ); ?></h3>

		<div class="loop-description">
			<?php echo term_description( '', get_query_var( 'taxonomy' ) ); ?>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta -->

<?php elseif ( is_author() ) : ?>

	<?php
		$user_id = get_query_var( 'author' );
		$name = get_the_author_meta( 'display_name', $user_id );
	?>

	<div id="hcard-<?php the_author_meta( 'user_nicename', $user_id ); ?>" class="loop-meta-tag vcard">

		<h3 class="loop-title"><?php printf( __( 'Author: %s', 'cakifo' ), '<span class="fn n">' . $name . '</span>' ); ?></h3>

		<div class="loop-description">
			<?php echo get_avatar( get_the_author_meta( 'user_email', $user_id ), 96 ); ?>

			<?php echo wpautop( get_the_author_meta( 'description', $user_id ) ); ?>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta -->

<?php elseif ( is_search() ) : ?>

	<div class="loop-meta-tag">

		<?php $results = absint( $wp_query->found_posts ); ?>

		<h3 class="loop-title"><?php printf( _n( '%1$d Search Result for: %2$s', '%1$d Search Results for: %2$s', $results, 'cakifo' ), $results, '<span>' . esc_attr( get_search_query() ) . '</span>' ); ?></h3>

		<div class="loop-description">
			<p><?php printf( __( 'You are browsing the search results for &quot;%1$s&quot;', 'cakifo' ), esc_attr( get_search_query() ) ); ?></p>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta -->

<?php elseif ( is_date() ) : ?>

	<div class="loop-meta-tag">

		<h3 class="loop-title"><?php _e( 'Archives by date', 'cakifo' ); ?></h3>

		<div class="loop-description">
			<p><?php _e( 'You are browsing the site archives by date.', 'cakifo' ); ?></p>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta -->

<?php elseif ( is_post_type_archive() ) : ?>

	<?php $post_type = get_post_type_object( get_query_var( 'post_type' ) ); ?>

	<div class="loop-meta-tag">

		<h3 class="loop-title"><?php post_type_archive_title(); ?></h3>

		<div class="loop-description">
			<?php
				if ( ! empty( $post_type->description ) )
					echo wpautop( $post_type->description );
			?>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta -->

<?php elseif ( is_archive() ) : ?>

	<div class="loop-meta-tag">

		<h3 class="loop-title"><?php _e( 'Archives', 'cakifo' ); ?></h3>

		<div class="loop-description">
			<p><?php _e( 'You are browsing the site archives.', 'cakifo' ); ?></p>
		</div> <!-- .loop-description -->

	</div> <!-- .loop-meta -->

<?php endif; ?>

<?php
}

/**
 * Google Breadcrumbs shortcodes
 *
 * @since 0.1.0
 */
function yui_news_google_breadcrumb_menu_shortcode() {
	echo '<div class="googlebreadcrumb">';
	echo googleBreadcrumbs(); 
	echo '</div>';
}
function yui_news_home_share_link_shortcode() {
	include(TEMPLATEPATH. '/inc/home/share-home.html');
}
function yui_news_comment_count_shortcode() {
	echo '<span style="float:right;">'; echo commentCount(); echo '</span>';
}
function yui_news_entry_share_link_shortcode() {
	include(TEMPLATEPATH. '/inc/share_this_buttons.html');
}

/**
 * Facebook share link shortcode.
 *
 * @note This won't work from your computer (http://localhost). Must be a live site.
 * @link http://developers.facebook.com/docs/reference/plugins/like/
 * @since 1.0
 * @param array $atts
 */
function yui_news_entry_fblike_live_link_shortcode( $atts ) {
	
	static $first = true;

	extract( shortcode_atts( array(
		'before' => '',
		'after' => '',
		'href' => get_permalink(),
		'layout' => 'standard', // standard, button_count, box_count
		'action' => 'like', // like, recommend
		'width' => 450,
		'faces' => 'false', // true, false
		'colorscheme' => 'light', // light, dark
		'locale' => get_locale(), // Language of the button - ex: da_DK, fr_FR
 	), $atts) );
	
	// Set default locale
	$locale = ( isset( $locale ) ) ? $locale : 'en_US';

	// Only add the script once
	$script = ( $first == true ) ? "<script>(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0];if (d.getElementById(id)) {return;}js = d.createElement(s); js.id = id;js.src = '//connect.facebook.net/$locale/all.js#xfbml=1';fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script>" : "";

	$first = false;

	$text = '<div class="fb-like" data-href="' . esc_url( $href ) . '" data-send="false" data-layout="' . esc_attr( $layout ) . '" data-width="' . intval( $width ) . '" data-show-faces="' . esc_attr( $faces ) . '" data-action="' . esc_attr( $action ) . '" data-colorscheme="' . esc_attr( $colorscheme ) . '"></div>';

	return $before . $text . $after . $script;
}
//?FACEBOOK LIKE

/**
 * Google +1 shortcode
 *
 * @link http://www.google.com/+1/button/
 * @since 1.2
 * @param array $atts
 */
function cakifo_entry_googleplus_link_shortcode( $atts ) {

	static $first = true;

	extract( shortcode_atts( array(
		'before' => '',
		'after' => '',
		'href' => get_permalink(),
		'layout' => 'standard', // small, medium, standard, tall
		'callback' => '',
		'count' => 'true' // true, false
 	), $atts) );

	// Only add the script once
	$script = ( $first == true ) ? "<script>(function() {var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;po.src = 'https://apis.google.com/js/plusone.js';var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);})();</script>" : "";

	$first = false;

	$text = '<div class="g-plusone" data-size="' . $layout . '" data-count="' . $count . '" data-href="' . $href . '" data-callback="' . $callback . '"></div>';

	return $before . $text . $after . $script;
} 
function yui_news_entry_technocrati_link_shortcode() {
	$url = esc_url( 'http://technorati.com/faves?add=' . urlencode( get_permalink( get_the_ID() ) ) . '&amp;amp;title=' . urlencode( the_title_attribute( 'echo=0' ) ) );
	return '<a target="_blank" rel="nofollow external" class="icon-technorati" href="' . $url . '" title="' . __( 'Link to Technocrati', hybrid_get_textdomain() ) . '">' . __( 'Technocrati', hybrid_get_textdomain() ) . '</a>';
}
function yui_news_entry_sphere_link_shortcode() {
	$url = esc_url( 'http://www.sphere.com/search?q=sphereit:' . urlencode( get_permalink( get_the_ID() ) ) . '&title=' . urlencode( the_title_attribute( 'echo=0' ) ) );
	return '<a target="_blank" rel="nofollow external" class="icon-spehere" href="' . $url . '" title="' . __( 'Sphere the Content', hybrid_get_textdomain() ) . '">' . __( 'Sphere', hybrid_get_textdomain() ) . '</a>';	
}

// TWEETER
function yui_news_entry_small_tweetme_count_link_shortcode() {?>
<script type="text/javascript">tweetmeme_style = 'compact';tweetmeme_url = '<data:post.url/>';</script>
<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script>
<?php
}
function yui_news_entry_tweet_counts_link_shortcode() {?>
<div style="float:right; padding:5px;margin-top:-25px;" class="bt bb">
<a href="http://twitter.com/share" class="twitter-share-button" data-count="horizontal" data-via="tricksdaddy">Tweet</a>
<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
</div>
<?php
}
//PMNEWS HACKS FOR MORE SOCIAL BOOKMARKING
function yui_news_entry_stumbleupon_link_shortcode() {
	$url = esc_url( 'http://www.stumbleupon.com/submit?url=' . urlencode( get_permalink( get_the_ID() ) ) . '&title=' . urlencode( the_title_attribute( 'echo=0' ) ) );
	return '<a target="_blank" rel="nofollow external" class="icon-stumble" href="' . $url . '" title="' . __( 'Stumble it!', hybrid_get_textdomain() ) . '">' . __( '', hybrid_get_textdomain() ) . '</a>';
}
function yui_news_entry_stumbleupon_counts_shortcode() {
echo '<div class="stumbleupon_button"><script src="http://www.stumbleupon.com/hostedbadge.php?s=5&r=<?php the_permalink(); ?>"></script></div>';
return '<a target="_blank" rel="nofollow external" class="icon-stumble" href="' . $url . '" title="' . __( 'Stumbled Count!', hybrid_get_textdomain() ) . '">' . __( '', hybrid_get_textdomain() ) . '</a>';
}
function yui_news_entry_gbuzz_counts_shortcode() {
echo '<a title="Post to Google Buzz" class="google-buzz-button" href="http://www.google.com/buzz/post" data-button-style="small-count" data-locale="en_GB" data-url="http://papuapost.com"></a>
<script type="text/javascript" src="http://www.google.com/buzz/api/button.js"></script>';
}

function yui_news_entry_digg_counts_link_shortcode() {
echo '<script type="text/javascript">(function() {
var s =document.createElement("SCRIPT"), s1 =document.getElementsByTagName("SCRIPT")[0];
s.type = "text/javascript";s.async = true;s.src = "http://widgets.digg.com/buttons.js";
s1.parentNode.insertBefore(s, s1);})();</script><a class="DiggThisButton DiggCompact"></a>';
}
//add_action( 'after_entry', 'digg_this', 11 );


function yui_news_entry_reddit_count_shortcode() {
	echo '<script type="text/javascript">reddit_url="[URL]"</script><script type="text/javascript">reddit_title="[TITLE]"</script><script type="text/javascript" src="http://www.reddit.com/button.js?t=1"></script>';
	return '<a target="_blank" rel="nofollow external" class="icon-reddit" href="' . $url . '" title="' . __( 'Submit this news to Reddit', hybrid_get_textdomain() ) . '">' . __( 'Reddit', hybrid_get_textdomain() ) . '</a>';
}

function yui_news_entry_sharemore_link_shortcode() {
	$url = esc_url( 'http://www.addthis.com/bookmark.php?pub=papua&amp;url=' .'&amp;title=' . urlencode( get_permalink( get_the_ID() ) ) . urlencode( the_title_attribute( 'echo=0' ) ) );
	return '<a target="_blank" rel="nofollow external" class="icon-addthis" href="' . $url . '" title="' . __( 'Share More on AddThis', hybrid_get_textdomain() ) . '">' . __( 'AddThis', hybrid_get_textdomain() ) . '</a>';
}
function yui_news_entry_excite_link_shortcode() {
	$url = esc_url( 'http://www.excites.com/save_link/?url=' .'&title=' . urlencode( get_permalink( get_the_ID() ) ) . urlencode( the_title_attribute( 'echo=0' ) ) );
	return '<a target="_blank" rel="nofollow external" class="icon-excite" href="' . $url . '" title="' . __( 'Share on Excites.com', hybrid_get_textdomain() ) . '">' . __( 'Excites', hybrid_get_textdomain() ) . '</a>';
}
// Add a linkedin share button widget = [entry-linkedin-link]
function yui_news_entry_linkedin_link_shortcode() {
	return '<a target="_blank" rel="nofollow external" class="icon-linkedin" href="' . $url . '" title="' . __( 'Share this news to Linkedin', hybrid_get_textdomain() ) . '">' . __( 'Linkedin', hybrid_get_textdomain() ) . '</a>';
	echo '<script type="text/javascript" src="http://platform.linkedin.com/in.js"></script><script type="in/share" data-url="<? the_permalink(); ?>" data-counter="top"></script>';
}
//add_action( 'hybrid_after_entry', 'entry-fblikes-link', 11 );
function yui_news_entry_pdf_link_shortcode() {
if ($attr['href']) {
        return '<a class="pdf" href="http://docs.google.com/viewer?url=' . $attr['href'] . '">'.$content.'</a>';
    } else {
        $src = str_replace("=", "", $attr[0]);
        return '<a class="pdf" href="http://docs.google.com/viewer?url=' . $src . '">'.$content.'</a>';
    }
}
function yui_news_entry_socializeit_link_shortcode() {
$tag = "papua"; //change this to fit the title of your page
$tag = urlencode($tag);
$url = "http://papuapost.com/" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; 
$url = urlencode($url);
echo <<<EOD
<a target="_blank" rel="nofollow external" class="icon-socializeit" href="http://www.socialize-it.com/index.php?url=$url&tag=$tag"></a>
EOD;
}

/**
 * Twitter username and/or link.
 *
 * Taken from my Twitter Profile Field plugin
 *
 * @link http://wordpress.org/extend/plugins/twitter-profile-field/
 * @since 1.0
 * @param array $atts
 */
function cakifo_twitter_shortcode( $atts ) {
	extract( shortcode_atts( array(   
    	'link' => true,
		'before' => '',
		'after' => '',
		'username' => hybrid_get_setting( 'twitter_username' ),
		'text' => __( 'Follow me on Twitter', 'cakifo' )
 	), $atts ) );

	if ( empty( $username ) )
		return;

	if ( ! $link )
		return $username;
	else
		return $before . '<a href="http://twitter.com/' . esc_attr( $username ) . '" class="twitter-profile">' . $text . '</a>' . $after;
}

/**
 * Twitter link shortcode.
 *
 * @since 1.0
 * @param array $atts
 */
function cakifo_entry_twitter_link_shortcode( $atts ) {
	extract( shortcode_atts( array(
		'before' => '',
		'after' => '',
		'href' => get_permalink(),
		'text' => the_title_attribute( 'echo=0' ),
		'layout' => 'horizontal', // horizontal, vertical, none
		'via' => hybrid_get_setting( 'twitter_username' ),
		'width' => 55, // Only need to use if there's no add_theme_support( 'cakifo-twitter-button' )
		'height' => 20, // Only need to use if there's no add_theme_support( 'cakifo-twitter-button' )
 	), $atts) );

	// Load the PHP tweet button script if the theme supports it
	if ( current_theme_supports( 'cakifo-twitter-button' ) ) :

		return cakifo_tweet_button( array(
			'before' => $before,
			'after' => $after,
			'layout' => $layout,
			'href' => $href,
			'text' => $text,
			'layout' => $layout,
			'via' => $via,
		) );

	// Load the Twitter iframe
	else :

		// Set the height to 62px if the layout is vertical and the height is the default value
		if ( $layout == 'vertical' && $height == 20 )
			$height = 62;

		// Set width to 110px if the layout is horizontal and the width is the default value
		if ( $layout == 'horizontal' && $width == 55 )
			$width = 110;

		// Build the query
		$query_args = array(
			'url' => $href,
			'via' => esc_attr( $via ),
			'text' => esc_attr( $text ),
			'count' => esc_attr( $layout )
    	);

		return $before . '<iframe src="http://platform.twitter.com/widgets/tweet_button.html?' . http_build_query( $query_args, '', '&amp;' ) . '" class="twitter-share-button" style="width:' . intval( $width ) . 'px; height:' . intval( $height ) . 'px;" scrolling="no" seamless></iframe>' . $after;

	endif;
}
 
/**
 * Displays the post format of the current post
 *
 * @since 1.3
 * @param array $atts
 */
function cakifo_entry_format_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'before' => '',
		'after' => ''
	), $atts );

	return $atts['before'] . get_post_format() . $atts['after'];
}

function cakifo_entry_type_shortcode( $posttype ) { 
$posttype = shortcode_atts( array(
		'before' => '<span class="meta-sep">&nbsp&para;&nbsp;&nbsp;',
		'after' => '</span>'
	), $posttype );

	return $posttype['before'] . get_post_type( $post->ID) . $posttype['after'];
}

/*
Plugin Name: Build Own Custom Taxonomy
Plugin URI: http://mtdewvirus.com/code/wordpress-plugins/
*/
function yui_news_source_meta_shortcode ($taxo_text) {
// Let's find out if we have taxonomy information to display
// Something to build our output in
$taxo_text = "";

// Variables to store each of our possible taxonomy lists
// This one checks for an Operating System classification
$os_list = get_the_term_list( $post->ID, 'yui_news_source', '<strong>News Source(s):</strong> ', ', ', '' );
}
//add_shortcode( 'yui-news-source-meta', 'yui_news_source_meta_shortcode' );	
/*
Plugin Name: Shortcode to display external files on your posts
Plugin URI: http://www.wprecipes.com/shortcode-to-display-external-files-on-your-posts
*/
function show_file_func( $atts ) {
  extract( shortcode_atts( array(
    'file' => ''
  ), $atts ) );
 
  if ($file!='')
    return @file_get_contents($file);
}
 
function yui_news_home_archive_content_shortcode () { ?> 
	<div id="post-<?php the_ID() ?>" class="post <?php hybrid_entry_class() ?>">
  		<?php do_atomic( 'before_entry' ); // hybrid_before_entry ?>
  	<?php get_the_image( array( 'custom_key' => false, 'the_post_thumbnail' => false, 'default_size' => 'thumbnail', 'image_scan' => true, 'width' => '125', 'default_image' => './wp-content/uploads/images/default_thumb.gif' ) ); ?>    	
  	<div class="bd">
		<div class="fixed">
   	<?php the_excerpt('350');	?>
    <div class="clear"></div>
		</div><!--.bd-->
	</div><!--.fixed-->
		<div class="entry-meta">
		<?php echo apply_atomic_shortcode( 'entry_meta', '' . __( '[entry-tags-with-count before="Tagged "] [last-modified] [entry-words-count] [cakifo-entry-type] [cakifo-entry-format before=" | "]', 'hybrid-yui-news' ) . '' ); ?>
		</div><!--.entry-meta-->
	</div><!--.hentry-->
 <?php
}
/**
 * Additional helper functions that the framework or themes may use.  The functions in this file are functions
 * that don't really have a home within any other parts of the framework.
 *
 * @package HybridCore
 * @subpackage Functions
 */

/* Add extra support for post types. */
//add_action( 'init', 'hybrid_add_post_type_support' );

/* Add extra file headers for themes. */
//add_filter( 'extra_theme_headers', 'hybrid_extra_theme_headers' );

function pmmews_breadcrumb_tags_title() {
	global $wp_query;
echo '<h5 class="gr"><span class="tagsheading">';
if ( is_home() || is_front_page() || is_page_template('page-template-home.php')) :
		echo 'Welcome! Wa!, Wa!, Salam!';
	 elseif ( is_category() ) :
//	echo do_action( 'taxonomy_image_plugin_print_image_html', 'detail' );
		echo wp_title();
	elseif ( is_tag() ) : 
//	echo do_action( 'taxonomy_image_plugin_print_image_html', 'detail' ); 
		echo wp_title();
	elseif ( is_archive() ) : 
		echo 'Archives:&nbsp;'; echo wp_title();	
	elseif ( is_attachment() ) : 
		echo 'Image:&nbsp;'; echo wp_title();
	elseif ( is_singular('post') ) :
		echo tagAndCatBreadCrumb(); 
	elseif ( is_search() ) : 
		echo esc_attr( get_search_query() ); 
	elseif ( is_date() ) :	
		echo 'Archives:&nbsp;'; echo wp_title();	
	elseif ( is_page() ) : 
	//	echo do_action( 'taxonomy_image_plugin_print_image_html', 'detail' ); 
		 echo wp_title();
	elseif ( is_author() ) :
		the_author_meta( 'display_name', $id ); 
	elseif (array( 'post_type') ) :
	$posttype = get_post_type( $post->ID ); if ( $posttype) { echo '(' . $posttype . 's)'; }
	echo tagAndCatBreadCrumb(); 	
	 endif; 	
echo '</span></h5>';
echo yui_news_sidebar_pagination();
echo '<br clear="left">';
}
function yui_news_header_logo() { ?>
 	  <a id="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php
			// Check if this is a post or page, if it has a thumbnail, and if it's a big one
				if ( is_singular() &&
						has_post_thumbnail( $post->ID ) &&
						( /* $src, $width, $height */ $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'post-thumbnail' ) ) &&
						$image[1] >= HEADER_IMAGE_WIDTH ) :
					// Houston, we have a new header image!
					echo get_the_image( array( 'custom_key' => false, 'the_post_thumbnail' => false, 'default_size' => 'header-image', 'image_scan' => true, 'width' => '125', 'default_image' => '.wp-content/uploads/images/default_thumb.gif' ) ); 
				else : ?>
					<img src="<?php header_image(); ?>" width="<?php echo HEADER_IMAGE_WIDTH; ?>" height="<?php echo HEADER_IMAGE_HEIGHT; ?>" alt="" />
		<?php endif; ?></a>
<?php
}
function yui_news_site_header() {?>
		<hgroup>
		<a href='<?php home_url(); ?>' title='Papua Merdeka News'>
	<div id='site-title'>	
	<h6 class="gr" style="font-size:120%;letter-spacing:6px;">Papua</h6>
	<span style="font-size:55%;"><h6 class="g">M</h6><h6 class="o1">e</h6><h6 class="o2">r</h6><h6 class="lg">d</h6><h6 class="l">e</h6><h6 class="e">k</h6><h6 class="g">a</h6><h6 class="e">!</h6></span><h6 class="y1" style="text-decoration:none; letter-spacing:0.2em;font-size:30px;margin-top:20px;"><span><em>News</em></span></h6>
	</div><!--id="blog-title"-->
<!--id="heading"-->
	</a><br clear="left">
		</hgroup>
<?php 
}

function yui_news_site_description() { 
echo '<div class="feat-tags">';
 if (is_home()) echo hybrid_site_description();
if (is_category()) echo category_description();
if (is_tag()) echo tag_description();
	if (is_tax()) single_term_title();  
	if (is_tax()) echo tagAndCatBreadCrumb();  
	if (is_author()) the_author_meta( 'user_nicename', $id );
	if (is_singular('post')) wp_title();
	if (is_search()) printf( __( 'You are browsing the search results for &quot;%1$s&quot;', hybrid_get_textdomain() ), esc_attr( get_search_query() ) ); 
echo '</div>';	
}

// Link Post Title to External URL
if ( ! function_exists( 'print_title' ) ) :

function print_title() {
	global $post;
    $thePostID = $post->ID;
    $post_id = get_post($thePostID);
    $title = $post_id->post_title;
    $perm = get_permalink($post_id);
    $post_keys = array(); $post_val = array();
    $post_keys = get_post_custom_keys($thePostID);

    if (!empty($post_keys)) {
		foreach ($post_keys as $pkey) {
			if ($pkey=='title_url') {
				$post_val = get_post_custom_values($pkey);
			}
		}
		if (empty($post_val)) {
			$link = $perm;
		} else {
			$link = $post_val[0];
		}
    } else {
		$link = $perm;
    }
    echo '<h3><a class="catheader" href="'.$link.'" rel="bookmark" title="'.$title.'">'.$title.'</a></h3>';
	echo '<div class="entry-subtitle">'; echo apply_atomic_shortcode( 'entry_subtitle', '[entry-subtitle]' );  echo '</div>';
}

endif;
if ( ! function_exists( 'short_title' ) ) :
// to control the post title length
function short_title() {
 $title = get_the_title();
 $count = strlen($title);
 if ($count >= 65) {
 $title = substr($title, 0, 55);
 $title .= '...';
 }
 echo $title;
}
endif;

if ( ! function_exists( 'print_archive_title' ) ) :
/**
 * Displays the published date of an individual post.
 *
 * @since 0.7
 * @param array $attr
 */
// Link Post Title to External URL
// Link Post Title to External URL
function print_archive_title() {
	global $post;
    $thePostID = $post->ID;
    $post_id = get_post($thePostID);
    $title = $post_id->post_title;
    $perm = get_permalink($post_id);
    $post_keys = array(); $post_val = array();
    $post_keys = get_post_custom_keys($thePostID);

    if (!empty($post_keys)) {
		foreach ($post_keys as $pkey) {
			if ($pkey=='title_url') {
				$post_val = get_post_custom_values($pkey);
			}
		}
		if (empty($post_val)) {
			$link = $perm;
		} else {
			$link = $post_val[0];
		}
    } else {
		$link = $perm;
    }
    echo '<h2 class="catheader" style=text-align:left;><a href="'.$link.'" rel="bookmark" title="'.$title.'">'.$title.'</a></h2>';
	echo '<h3 class="entry-subtitle">'; echo apply_atomic_shortcode( 'entry_subtitle', '[entry-subtitle]' );  echo '</h3>';	
}
endif;


if ( ! function_exists( 'yui_news_subheader_loop_meta' ) ) :

function yui_news_subheader_loop_meta() {?>
<div class="yui-cms-accordion multiple fade fixIE">
 <div class="yui-cms-item yui-panel selected">
 				<div class="hd"><span>				
							<?php if ( is_home() || is_front_page() || is_page_template('page-template-home.php') ) : ?>
&nbsp;&raquo;&nbsp;&rang;&nbsp;<?php echo googleBreadcrumbs();?>			
			 <?php elseif ( is_archive() ) : ?>
			 &nbsp;&raquo;&nbsp;&rang;&nbsp;<?php echo googleBreadcrumbs();?>
			  <?php elseif ( is_singular('post') ) : ?>
			<?php echo apply_atomic_shortcode( 'entry_meta', '<span class="">' . __( '&nbsp; [entry-words-count] [last-modified before="| "] [entry-views before=" Views: "]', hybrid_get_textdomain() ) . '</span><div class="clear"></div>' ); ?>
			  
		  <?php else : ?>				 
					<?php endif; ?>		

				</span></div>
<div class="bd">  
	<div class="fixed"> 
  <?php echo pmmews_breadcrumb_tags_title();?>
	</div><!-- .fixed -->
	</div><!-- .bd -->
   <div class="ft"><a href="#" class="accordionToggleItem">
   <?php if ( is_singular()) : ?>
 	<?php elseif ( is_category() ) : ?>
	 <?php $description = category_description( '', get_query_var( 'taxonomy' ) ); ?>
	<?php if ( !empty( $description ) ) echo '<span class="headlines">' . $description . '</span>'; ?>
	 <?php elseif ( is_tag() ) : ?> 
	 	<?php $description = tag_description( '', get_query_var( 'post_tag' ) ); ?>
			<?php if ( !empty( $description ) ) echo '<span class="headlines">' . $description . '</span>'; ?>
		
	 <?php else : ?>				 
	 	<?php echo do_shortcode('[yui-news-site-description]'); ?>			
				<?php endif; ?>		
			</a>
			<?php echo '&nbsp;&nbsp;'; echo yui_news_entry_font_size_shortcode(); ?>
			
			</div>				
	<div class="actions">
	<a href="#" class="accordionToggleItem">&nbsp;</a> 
	<a href="#" class="accordionRemoveItem">&nbsp;</a> 
	</div>
		</div><!-- .yui-cms-item yui-panel -->		

	</div><!-- class="yui-cms-accordion multiple fade fixIE"" -->
<?php
}
endif;

 
/**
 * Shortlink popup shortcode.
 *
 * @since 0.1.0
 */
function yui_news_entry_shortlink_popup_shortcode() {
	$shortlink = wp_get_shortlink( get_the_ID() );

	if ( empty( $shortlink ) )
		return '';

	$id = 'shortlink-' . get_the_ID();
	$title = sprintf( __( "Shortlink for '%s'", hybrid_get_textdomain() ), get_the_title() );
	$out = '<a class="tips shortlink hide-if-no-js" rel="#' . $id . '" title="' . esc_attr( $title ) . '">' . __( 'Shortlink', hybrid_get_textdomain() ) . '</a>';
	$out .= ' <div id="' . $id . '" class="tip hide">';
	$out .= '<input type="text" value="' . esc_url( $shortlink ) . '" onclick="this.focus(); this.select();" />';
	$out .= '</div>';

	return $out;
}

/**
 * Print link shortcode.
 *
 * @since 0.1.0
 */
function yui_news_entry_print_link_shortcode() {
	return '<a class="print-link hide-if-no-js" href="#">' . __( 'Print', hybrid_get_textdomain() ) . '</a>';
}

/**
 * Email link shortcode.
 *
 * @since 0.1.0
 */
function yui_news_entry_email_link_shortcode() {
	$subject = urlencode( esc_attr( '[' . get_bloginfo( 'name' ) . ']' . the_title_attribute( 'echo=0' ) ) );
	$body = urlencode( esc_attr( sprintf( __( 'Check out this post: %1$s', hybrid_get_textdomain() ), get_permalink( get_the_ID() ) ) ) );
	return '<a class="email-link" href="mailto:?subject=' . $subject . '&amp;body=' . $body . '">' . __( 'Email', hybrid_get_textdomain() ) . '</a>';
}

/**
 * Mixx link shortcode.
 *
 * @since 0.1.0
 */
function yui_news_entry_mixx_link_shortcode() {
	return '<a href="http://www.mixx.com" onclick="window.location=\'http://www.mixx.com/submit?page_url=\'+window.location; return false;">' . __( 'Mixx', hybrid_get_textdomain() ) . '</a>';
}

/**
 * Delicious link shortcode.
 *
 * @since 0.1.0
 */
function yui_news_entry_delicious_link_shortcode() {
	return '<a class="icon-delicious" href="http://delicious.com/save" onclick="window.open(\'http://delicious.com/save?v=5&amp;noui&amp;jump=close&amp;url=\'+encodeURIComponent(\'' . get_permalink() . '\')+\'&amp;title=\'+encodeURIComponent(\'' . the_title_attribute( 'echo=0' ) . '\'),\'delicious\', \'toolbar=no,width=550,height=550\'); return false;">' . __( 'Delicious', hybrid_get_textdomain() ) . '</a>';
}

/**
 * Digg link shortcode.
 * @note This won't work from your computer (http://localhost). Must be a live site.
 *
 * @since 0.1.0
 */
function yui_news_entry_digg_link_shortcode() {
	$url =  esc_url( 'http://digg.com/submit?phase=2&amp;url=' . urlencode( get_permalink( get_the_ID() ) ) . '&amp;title="' . urlencode( the_title_attribute( 'echo=0' ) ) );

	return '<a class="icon-digg" href="' . $url . '" title="' . __( 'Digg this entry', hybrid_get_textdomain() ) . '">Digg</a>';
}

/**
 * Facebook share link shortcode.
 *
 * @todo Figure out why this doesn't work.
 *
 * @since 0.1.0
 */
function yui_news_entry_facebook_link_shortcode() {
	$url = esc_url( 'http://facebook.com/sharer.php?u=' . urlencode( get_permalink( get_the_ID() ) ) . '&amp;t=' . urlencode( the_title_attribute( 'echo=0' ) ) );

	return '<a class="icon-facebook" href="' . $url . '" title="' . __( 'Share this entry on Facebook', hybrid_get_textdomain() ) . '">' . __( 'Facebook', hybrid_get_textdomain() ) . '</a>';
}

/**
 * Twitter link shortcode.
 *
 * @since 0.1.0
 */
function yui_news_entry_twitter_link_shortcode() {

	$post_id = get_the_ID();

	$post_type = get_post_type( $post_id );

	if ( 'post' == $post_type || 'page' == $post_type || 'attachment' == $post_type )
		$shortlink = wp_get_shortlink( $post_id );
	else
		$shortlink = get_permalink( $post_id );

	$url = esc_url( 'http://twitter.com/home?status=' . urlencode( sprintf( __( 'Currently reading %1$s', hybrid_get_textdomain() ), $shortlink ) ) );
	return '<a class="icon-twitter" href="' . $url . '" title="' . __( 'Share this entry on Twitter', hybrid_get_textdomain() ) . '">' . __( 'Twitter', hybrid_get_textdomain() ) . '</a>';
}

/**
 * Slideshow shortcode.
 *
 * @since 0.1.0
 */
function yui_news_slideshow_shortcode( $attr ) {
	global $post;

	/* Set up the defaults for the slideshow shortcode. */
	$defaults = array(
		'order' => 'ASC',
		'orderby' => 'menu_order ID',
		'id' => $post->ID,
		'size' => 'news-slideshow',
		'include' => '',
		'exclude' => '',
		'numberposts' => -1,
	);
	$attr = shortcode_atts( $defaults, $attr );

	/* Allow users to overwrite the default args. */
	extract( apply_atomic( 'slideshow_shortcode_args', $attr ) );

	/* Arguments for get_children(). */
	$children = array(
		'post_parent' => intval( $id ),
		'post_status' => 'inherit',
		'post_type' => 'attachment',
		'post_mime_type' => 'image',
		'order' => $order,
		'orderby' => $orderby,
		'exclude' => absint( $exclude ),
		'include' => absint( $include ),
		'numberposts' => intval( $numberposts ),
	);

	/* Get image attachments. If none, return. */
	$attachments = get_children( $children );

	if ( empty( $attachments ) )
		return '';

	/* If is feed, leave the default WP settings. We're only worried about on-site presentation. */
	if ( is_feed() ) {
		$output = "\n";
		foreach ( $attachments as $id => $attachment )
			$output .= wp_get_attachment_link( $id, $size, true ) . "\n";
		return $output;
	}

	$slideshow = '<div class="slideshow-set"><div class="slideshow-items">';

	$i = 0;

	foreach ( $attachments as $attachment ) {

		/* Open item. */
		$slideshow .= '<div class="slideshow-item item item-' . ++$i . '">';

		/* Get image. */
		$slideshow .= wp_get_attachment_link( $attachment->ID, $size, true, false );

		/* Check for caption. */
		if ( !empty( $attachment->post_excerpt ) )
			$caption = $attachment->post_excerpt;
		elseif ( !empty( $attachment->post_content ) )
			$caption = $attachment->post_content;
		else
			$caption = '';

		if ( !empty( $caption ) ) {
			$slideshow .= '<div class="slideshow-caption">';
			$slideshow .= '<a class="slideshow-caption-control">' . __( 'Caption', hybrid_get_textdomain() ) . '</a>';
			$slideshow .= '<div class="slideshow-caption-text">' . $caption . '</div>';
			$slideshow .= '</div>';
		}

		$slideshow .= '</div>';
	}

	$slideshow .= '</div><div class="slideshow-controls">';

		$slideshow .= '<div class="slideshow-pager"></div>';
		$slideshow .= '<div class="slideshow-nav">';
			$slideshow .= '<a class="slider-prev">' . __( 'Previous', hybrid_get_textdomain() ) . '</a>';
			$slideshow .= '<a class="slider-next">' . __( 'Next', hybrid_get_textdomain() ) . '</a>';
		$slideshow .= '</div>';

	$slideshow .= '</div>';

	$slideshow .= '</div><!-- End slideshow. -->';

	return apply_atomic( 'slideshow_shortcode', $slideshow );
}

?>