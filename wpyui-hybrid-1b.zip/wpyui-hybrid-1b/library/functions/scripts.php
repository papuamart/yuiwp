<?php
/**
 * Functions file for loading scripts and stylesheets.  This file also handles the output of attachment files 
 * by displaying appropriate HTML elements for the attachments.
 *
 * @package HybridCore
 * @subpackage Functions
 */
add_action( 'after_setup_theme', 'pmnews_scripts_setup', 12 );

if ( ! function_exists( 'pmnews_scripts_setup' ) ):
/**
*/
function pmnews_scripts_setup() {
 
// Register and deregister Stylesheet and Scripts files	
if(!is_admin()) {
	add_action( 'wp_print_styles', 'my_deregister_styles', 100 );
	add_action( 'wp_print_scripts', 'my_deregister_scripts', 100 );
   	}
add_action('wp_footer', 'print_my_script');
 
function print_my_script() {
	global $add_my_script; 
	if ( ! $add_my_script )
		return;}
function my_deregister_scripts() {
		wp_deregister_script( 'jquery-1.3.2' );	
		wp_deregister_script( 'comment-ajax-scripts' );		
		wp_deregister_script( 'jquery-scrolltopcontrol' );	

		wp_register_script( 'jquery-1.3.2', esc_url( apply_atomic( 'jquery_132_scripts', get_stylesheet_directory_uri() .'/library/js/jquery-1.3.2.min.js' ) ), array( 'jquery' ), '1.3.2', true );
		wp_register_script( 'jquery-scrolltopcontrol', esc_url( apply_atomic( 'jquery_base_scripts', get_stylesheet_directory_uri() .'/library/js/scrolltopcontrol.js' ) ), array( 'jquery' ), '1.1', true );
		wp_register_script( 'comment-ajax-scripts', esc_url( apply_atomic( 'pmnews_comment_ajax_scripts', get_stylesheet_directory_uri() .'/library/js/comments-ajax.js' ) ), array( 'jquery' ), '1.3', true );
		wp_register_script('jquery', '/wp-includes/js/jquery/jquery.js', true, '1.4.2', true);
		wp_enqueue_script( 'jquery' );							
		wp_enqueue_script( 'jquery-1.3.2' );				
		wp_enqueue_script( 'comment-ajax-scripts' );				
		wp_enqueue_script( 'jquery-scrolltopcontrol' );			

		/*
		enqueue yui scripts
		*/
		wp_deregister_script( 'yui-utilities' );	
		wp_deregister_script( 'yui-bubbling-core' );	
		wp_deregister_script( 'bubbling-dispatcher' );	
		wp_deregister_script( 'yui-tabview' );
		wp_deregister_script( 'bubbling-accordion' );
		wp_deregister_script( 'bubbling-lighter' );
		wp_deregister_script( 'bubbling-tooltips' );
		wp_deregister_script( 'bubbling-init' );
		wp_deregister_script( 'bubbling-container' );
		
		wp_register_script('yui-utilities', trailingslashit( get_stylesheet_directory_uri()) .'library/js/yui/2.7.0/build/utilities/utilities.js', true, '2.7.0', false);
		wp_register_script('yui-bubbling-core', trailingslashit( get_stylesheet_directory_uri()) .'library/js/bubbling/2.0/build/package/core.js', true, '2.0');
		wp_register_script('bubbling-dispatcher', trailingslashit( get_stylesheet_directory_uri()) .'library/js/bubbling/2.0/build/dispatcher/dispatcher-min.js', false, '2.0', true);
		wp_register_script('yui-tabview', trailingslashit( get_stylesheet_directory_uri()) .'library/js/yui/2.2.2/build/tabview/tabview-min.js',  true, '2.2.2', false);
 
  		wp_register_script('bubbling-accordion', trailingslashit( get_stylesheet_directory_uri()) .'library/js/bubbling/2.0/build/accordion/accordion-min.js', false, '2.0', true);
		wp_register_script('bubbling-lighter', trailingslashit( get_stylesheet_directory_uri()) .'library/js/bubbling/2.0/build/lighter/lighter-min.js', false, '2.0', true);
		wp_register_script('bubbling-tooltips', trailingslashit( get_stylesheet_directory_uri()) .'library/js/bubbling/2.0/build/tooltips/tooltips-min.js', false, '2.0', true);
		wp_register_script('bubbling-init', trailingslashit( get_stylesheet_directory_uri()) .'library/js/bubbling/0.1.1/build/init.js', false, '0.1.1', true);			
 		wp_register_script('yui-container', trailingslashit( get_stylesheet_directory_uri()) .'library/js/yui/2.2.2/build/container/container-min.js', false, '2.2.2', true );			
		
		wp_enqueue_script( 'yui-utilities' );				
		wp_enqueue_script( 'yui-bubbling-core' );				
		wp_enqueue_script( 'bubbling-dispatcher' );				
		wp_enqueue_script( 'yui-tabview' );				
			
		wp_enqueue_script( 'bubbling-accordion' );				
		wp_enqueue_script( 'bubbling-lighter' );				
		wp_enqueue_script( 'bubbling-tooltips' );				
		wp_enqueue_script( 'bubbling-init' );	
		wp_enqueue_script( 'yui-container' );	
	
if (is_attachment()) {
		/* this is particularly important for imagepanner.js to function */
		wp_deregister_script('imagepanner');
		wp_deregister_script('imageresizer');
		wp_deregister_script('yui3-min');
		wp_deregister_style('imagepanner');
		wp_deregister_style('imageresizer');
		wp_register_script( 'imagepanner', esc_url( apply_atomic( 'imagepanner_js', get_stylesheet_directory_uri() .'/library/js/imagepanner.js' ) ), array( 'jquery' ), '1.1', true );
		wp_register_script( 'imageresizer', esc_url( apply_atomic( 'imageresizer_js', get_stylesheet_directory_uri() .'/library/js/imageresizer.js' ) ), array( 'jquery' ), '1.1', true );
		wp_register_style( 'imagepanner', esc_url( apply_atomic( 'imagepanner_css', get_stylesheet_directory_uri() .'/library/css/imagepanner.css' )), true, '1.1' );
		wp_register_style( 'imageresizer', esc_url( apply_atomic( 'imageresizer_css', get_stylesheet_directory_uri() .'/library/css/imageresizer.css' )), true, '1.1' );
		wp_register_script( 'yui3-min', 'http://yui.yahooapis.com/3.14.0/build/yui/yui-min.js', array( 'jquery' ), '3.14.0', false );

		wp_enqueue_script('imagepanner');
		wp_enqueue_script('imageresizer');
		wp_enqueue_style( 'imagepanner');	
		wp_enqueue_style( 'imageresizer');	
		wp_enqueue_script('yui3-min');
		} 
	
}
	
		wp_deregister_style( 'bubblingaccordioncss' );		
		wp_deregister_style( 'bubblingmyAccordioncss' );		
		wp_deregister_style( 'yuitabviewtabs');
		wp_deregister_style( 'yuitabviewcss');
		wp_deregister_style( 'yuicontainercss');
 		
  		wp_register_style( 'bubblingaccordioncss', esc_url( apply_atomic( 'bubbling_accordion_css', get_stylesheet_directory_uri() .'/library/js/bubbling/2.0/build/accordion/assets/accordion.css' )), true, '1.3.3' );
  		wp_register_style( 'bubblingmyAccordioncss', esc_url( apply_atomic( 'bubbling_myAccordion_css', get_stylesheet_directory_uri() .'/library/js/bubbling/2.0/build/accordion/assets/myAccordion.css' )), true);
  		wp_register_style( 'yuitabviewtabs', esc_url( apply_atomic( 'yui_tabview_tabs_css', get_stylesheet_directory_uri() .'/library/js/yui/2.2.2/build/tabview/assets/border_tabs.css' )), true, '2.2.2' );
  		wp_register_style( 'yuitabviewcss', esc_url( apply_atomic( 'yui_tabview_css', get_stylesheet_directory_uri() .'/library/js/yui/2.2.2/build/tabview/assets/tabview.css' )), true, '2.2.2' );
  		wp_register_style( 'yuicontainercss', esc_url( apply_atomic( 'yui_container_css', get_stylesheet_directory_uri() .'/library/js/yui/2.2.2/build/container/assets/container.css' )), true, '2.2.2' );
 
		wp_enqueue_style( 'bubblingaccordioncss' );
		wp_enqueue_style( 'bubblingmyAccordioncss' );		
		wp_enqueue_style( 'yuitabviewtabs');
		wp_enqueue_style( 'yuitabviewcss');
		wp_enqueue_style( 'yuicontainercss');
 		
}
function my_deregister_styles() {	

if ( is_singular() && get_option( 'thread_comments' ) && comments_open() ){
	/* this is particularly important for comment-ajax.js to function */		
		wp_enqueue_script( 'comment-ajax-scripts' );
}

if (is_singular('slideshow') ){
	wp_deregister_script( 'news-theme' );
 	wp_register_script( 'news-theme', esc_url( apply_atomic( 'news_theme_scripts', get_stylesheet_directory_uri() .'/library/js/news-theme.js' ) ), array( 'jquery' ), '20120825', true );
	wp_enqueue_script( 'news-theme' );
	wp_deregister_style( 'feature-slideshow-video-css' );
	wp_register_style( 'feature-slideshow-video-css', esc_url( apply_atomic( 'slideshow_css', get_stylesheet_directory_uri() .'/library/css/slideshow.css' )),false, '1.1', 'screen' );
	wp_enqueue_style( 'feature-slideshow-video-css' );
		
	/* Remove the breadcrumb trail. */
	add_filter( 'breadcrumb_trail', '__return_false' );		
	} 
if (is_singular('video') ){
	wp_deregister_script( 'news-theme' );
 	wp_register_script( 'news-theme', esc_url( apply_atomic( 'news_theme_scripts', get_stylesheet_directory_uri() .'/library/js/news-theme.js' ) ), array( 'jquery' ), '20120825', true );
	wp_enqueue_script( 'news-theme' );
	wp_deregister_style( 'feature-slideshow-video-css' );
	wp_register_style( 'feature-slideshow-video-css', esc_url( apply_atomic( 'slideshow_css', get_stylesheet_directory_uri() .'/library/css/slideshow.css' )),false, '1.1', 'screen' );
	wp_enqueue_style( 'feature-slideshow-video-css' );
		
	/* Remove the breadcrumb trail. */
	add_filter( 'breadcrumb_trail', '__return_false' );		
	} 	
	
	}
endif;
?>