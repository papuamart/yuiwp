<?php

	/* Unregister WP widgets. */
	add_action( 'widgets_init', 'hybrid_news_unregister_widgets' );

	/* Register additional widgets. */
	add_action( 'widgets_init', 'hybrid_news_register_widgets' );
	
/**
 * Loads extra widget files and registers the widgets.
 * 
 * @since 0.1.0
 */
function hybrid_news_register_widgets() {

	/* Load the popular tabs widget. */
	if ( current_theme_supports( 'entry-views' ) ) {
		require_once( trailingslashit( CHILD_THEME_DIR ) . 'library/classes/widget-popular-tabs.php' );
		register_widget( 'News_Widget_Popular_Tabs' );
	}

	/* Load the image stream widget. */
	require_once( trailingslashit( CHILD_THEME_DIR ) . 'library/classes/widget-image-stream.php' );
	register_widget( 'News_Widget_Image_Stream' );

	/* Load the newsletter widget. */
	require_once( trailingslashit( CHILD_THEME_DIR ) . 'library/classes/widget-newsletter.php' );
	register_widget( 'News_Widget_Newsletter' );
	
	/* Load the newsletter widget. */
	require_once( trailingslashit( CHILD_THEME_DIR ) . 'library/classes/custom-posts-widget.php' );
	//register_widget( 'n2wp_latest_cpt_init' );
	
	/* Load the newsletter widget. */
	require_once( trailingslashit( CHILD_THEME_DIR ) . 'library/classes/single-bottom-widget.php' );
	register_widget( 'PMNews_Widget_Post_Navigation' );		
	
	/* Load the newsletter widget. */
	require_once( trailingslashit( CHILD_THEME_DIR ) . 'library/classes/widget-about.php' );
	register_widget( 'about_widget' );	
	
	/* Load the P2 RSS Tags widget. */
	require_once( trailingslashit( STYLESHEETPATH ) . 'library/classes/p2-tags.php' );
	register_widget( 'YUIWP_Recent_Tags' );	/* Load the P2 RSS Tags widget. */
	require_once( trailingslashit( STYLESHEETPATH ) . 'library/classes/p2-cats.php' );
	register_widget( 'YUIWP_Recent_Cats' );

	/* Load the newsletter widget. */
	require_once( trailingslashit( CHILD_THEME_DIR ) . 'library/classes/beeb-widget.php' );
	register_widget( 'PMThemeList' );
	register_widget( 'PMThemeLatestList' );
	register_widget( 'PMThemeCatLight' );
	register_widget( 'PMThemeThumbs' );
	register_widget( 'PMThemeVideo' );	

	/* Load related posts by taxobomy of singular. */	
	require_once( trailingslashit( CHILD_THEME_DIR ) . 'library/classes/widget-related-posts.php' );
	register_widget( 'Cakifo_Widget_Related_Posts' );	
	
	/* Load the widgets for fron-page layout. */
	require_once( trailingslashit( CHILD_THEME_DIR ) . 'library/classes/widget-papua.php' );

} 
function hybrid_news_unregister_widgets() {
	unregister_widget( 'News_Widget_Popular_Tabs' );
	unregister_widget( 'about_widget' );
	unregister_widget( 'PMNews_Widget_Post_Navigation' );
	unregister_widget( 'PMThemeList' );
	unregister_widget( 'PMThemeLatestList' );
	unregister_widget( 'PMThemeCatLight' );
	unregister_widget( 'PMThemeThumbs' );
	unregister_widget( 'PMThemeVideo' );
	unregister_widget( 'News_Widget_Image_Stream' );
	unregister_widget( 'News_Widget_Newsletter' );
	unregister_widget( 'YUIWP_Recent_Tags' );
	unregister_widget( 'YUIWP_Recent_Cats' );
}
?>