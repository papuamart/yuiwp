<?php
/**
 * Popular Tabs Widget Class
 *
 * The Popular Tabs widget lists posts by view count and comment count in a tabbed display using the 
 * jQuery UI Tabs feature.
 *
 * @since 0.1
 *
 * @package News
 * @subpackage Classes
 */

class News_Widget_Popular_Tabs extends WP_Widget {

	var $prefix;
	var $textdomain;

	/**
	 * Set up the widget's unique name, ID, class, description, and other options.
	 * @since 0.1.0
	 */
	function News_Widget_Popular_Tabs() {
		$this->prefix = hybrid_get_prefix();
		$this->textdomain = hybrid_get_textdomain();

		$widget_ops = array( 'classname' => 'popular-tabs', 'description' => __( 'Displays popular posts by number of views and comments in tab format.', $this->textdomain ) );
		$control_ops = array( 'width' => 200, 'height' => 350, 'id_base' => "{$this->prefix}-popular-tabs" );
		$this->WP_Widget( "{$this->prefix}-popular-tabs", __( 'News: Popular Tabs', $this->textdomain ), $widget_ops, $control_ops );
	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 * @since 0.1.0
	 */
	function widget( $args, $instance ) {
		extract( $args );

		$args = array();

		$post_type = $instance['post_type'];
		$posts_per_page = intval( $instance['posts_per_page'] );
		$views_tab_title = $instance['views_tab_title'];
		$comments_tab_title = $instance['comments_tab_title'];

		echo $before_widget;

		if ( $instance['title'] )
			echo $before_title . apply_filters( 'widget_title', $instance['title'] ) . $after_title; ?>

	<div id="mostpopulartabView" class="yui-navset">
				<ul class="yui-nav">
					<li class="selected"><a href="#poptabs1"><em><?php _e('View'); ?></em></a></li>
					<li><a href="#poptabs2"><em><?php _e('Comment'); ?></em></a></li>
					<li><a href="#poptabs3"><em><?php _e('Category'); ?></em></a></li>
					<li><a href="#poptabs4"><em><?php _e('Tag'); ?></em></a></li>
				</ul><!-- .ui-tabs-nav -->
	<div class="yui-content">	
				<div id="poptabs1">
			<div class="archiveheader"><strong>[+]&nbsp;<?php _e('Most Viewed Posts', 'papuamerdeka') ?></strong></div>
					<?php $loop = new WP_Query( array( 'post_type' => $post_type, 'caller_get_posts' => true, 'posts_per_page' => $posts_per_page, 'meta_key' => 'Views', 'orderby' => 'meta_value_num', 'order' => 'DESC' ) ); ?>

					<?php if ( $loop->have_posts() ) : ?>
				<div class="sidebarheader">
						<ul class="listing">

						<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
							<?php the_title( '<li><a href="' . get_permalink() . '" title="' . the_title_attribute( 'echo=0' ) . '">', '</a>' ); ?>
							<span class="count view-count"><?php printf( __( '(%1$s)', $this->textdomain ), get_post_meta( get_the_ID(), 'Views', true ) ); ?></span>
							</li>
						<?php endwhile; ?>

						</ul>
</div>
					<?php endif; ?>

				</div><!-- .ui-tabs-panel -->

				<div id="poptabs2">
<div class="archiveheader"><strong><?php _e('[+]&nbsp;Most Commented News', 'papuamerdeka') ?></strong></div>
					<?php $loop = new WP_Query( array( 'post_type' => $post_type, 'caller_get_posts' => true, 'posts_per_page' => $posts_per_page,  'orderby' => 'comment_count' ) ); ?>

					<?php if ( $loop->have_posts() ) : ?>
<div class="sidebarheader">
						<ul class="listing">

						<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
							<?php the_title( '<li><a href="' . get_permalink() . '" title="' . the_title_attribute( 'echo=0' ) . '">', '</a>' ); ?>
							<span class="count view-count"><?php printf( __( '(%1$s)', $this->textdomain ), get_comments_number() ); ?></span>
							</li>
						<?php endwhile; wp_reset_query(); ?>

						</ul>
</div>
					<?php endif; ?>

				</div><!-- .ui-tabs-panel -->
				<div id="poptabs3">
				<div class="archiveheader"><strong><?php _e('[+]&nbsp;Most Popular Categories', 'papuamerdeka') ?></strong></div>
				<div class="sidebarheader">
			<ul class="listing"><?php wp_list_categories('number=10&show_count=1&orderby=count&order=DESC&title_li=') ?>
				</ul></div>				
				</div><!-- .ui-tabs-panel -->
				<div id="poptabs4">
				 <div class="tagsmyAccordion1"> 
<div class="archiveheader"><strong><?php _e('[+]&nbsp;Most Popular Topics', 'papuamerdeka') ?></strong></div>
	  <?php
      $noOfTags = 10; 
      $noOfPosts = 5;      
      $cloudRight = get_tags("orderby=count&order=DESC&number=$noOfTags");
      foreach((array)$cloudRight as $tagRight) : ?>
	<div class="yui-cms-accordion multiple fade fixIE" id="mylist-first-accordion">	
          <?php        
          $postsRight = new WP_Query();
          $postsRight->query("tag={$tagRight->slug}&showposts=$noOfPosts");        
          ?>            
          <?php if ( $postsRight->have_posts() ) :?>		  
              	<div class="yui-cms-item" id="mylist-first-element"><h3 style="text-transform:capitalize;"><a href="#" class="accordionRemoveItem action" title="click to remove">&nbsp;</a> 
		      <a href="#" class="accordionToggleItem action" title="click to expand">&nbsp;</a> &raquo;&nbsp;<?php echo $tagRight->name ?></a></h3>
              <div class="bd">
              <div class="fixed">
			<?php while ( $postsRight->have_posts() ) : $postsRight->the_post(); ?>
             <ul class='listing'><li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
              </ul>	
			  <?php endwhile;?> </div></div> 
          <?php endif; ?></div> 	  
      <?php unset($postsRight); echo '</div>'; endforeach; ?>
</div><br clear="all">
				</div><!-- .ui-tabs-panel -->

			</div><!-- .ui-tabs-wrap -->
	</div><!-- id="mostpopulartabs" class="yui-navset"-->
<script type="text/javascript" charset="utf-8">
var oTabView = new YAHOO.widget.TabView("mostpopulartabView");
</script>

		<?php

		echo $after_widget;
	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 * @since 0.1.0
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance = $new_instance;

		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['views_tab_title'] = strip_tags( $new_instance['views_tab_title'] );
		$instance['comments_tab_title'] = strip_tags( $new_instance['comments_tab_title'] );
		$instance['posts_per_page'] = strip_tags( $new_instance['posts_per_page'] );
		$instance['post_type'] = strip_tags( $new_instance['post_type'] );

		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 * @since 0.1.0
	 */
	function form( $instance ) {

		//Defaults
		$defaults = array(
			'title' => __( 'Most', $this->textdomain ),
			'posts_per_page' => 3,
			'post_type' => 'post',
			'views_tab_title' => __( 'Viewed', $this->textdomain ),
			'comments_tab_title' => __( 'Commented', $this->textdomain )
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<div class="hybrid-widget-controls columns-1">
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', $this->textdomain ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'post_type' ); ?>"><?php _e( 'Post Type:', $this->textdomain ); ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id( 'post_type' ); ?>" name="<?php echo $this->get_field_name( 'post_type' ); ?>">
			<?php foreach ( get_post_types( array( 'publicly_queryable' => true ), 'objects' ) as $post_type ) {
				if ( post_type_supports( $post_type->name, 'entry-views' ) ) { ?>
					<option value="<?php echo $post_type->name; ?>" <?php selected( $instance['post_type'], $post_type->name ); ?>><?php echo $post_type->labels->singular_name; ?></option>
				<?php }
			} ?>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'posts_per_page' ); ?>"><?php _e( 'Limit:', $this->textdomain ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'posts_per_page' ); ?>" name="<?php echo $this->get_field_name( 'posts_per_page' ); ?>" value="<?php echo $instance['posts_per_page']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'views_tab_title' ); ?>"><?php _e( 'Views Tab Title:', $this->textdomain ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'views_tab_title' ); ?>" name="<?php echo $this->get_field_name( 'views_tab_title' ); ?>" value="<?php echo $instance['views_tab_title']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'comments_tab_title' ); ?>"><?php _e( 'Comments Tab Title:', $this->textdomain ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'comments_tab_title' ); ?>" name="<?php echo $this->get_field_name( 'comments_tab_title' ); ?>" value="<?php echo $instance['comments_tab_title']; ?>" />
		</p>
		</div>
		<div style="clear:both;">&nbsp;</div>
	<?php
	}
}

?>