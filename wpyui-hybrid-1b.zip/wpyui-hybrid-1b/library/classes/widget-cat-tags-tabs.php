<?php
/**
 * Popular Tabs Widget Class
 *
 * The Popular Tabs widget lists posts by view count and comment count in a tabbed display using the 
 * jQuery UI Tabs feature.
 *
 * @package News
 * @subpackage Includes
 * @since 0.1.0
 */

class Hybrid_YUI_Widget_CatTags_Tabs extends WP_Widget {

	/**
	 * Set up the widget's unique name, ID, class, description, and other options.
	 *
	 * @since 0.3.0
	 */
	function __construct() {

		/* Set up the widget options. */
		$widget_options = array(
			'classname' => 'popular-cattags-tabs',
			'description' => esc_html__( 'Displays popular posts by number of Tags and categories in tab format.', 'hybrid-yui' )
		);

		/* Set up the widget control options. */
		$control_options = array(
			'width' => 200,
			'height' => 350
		);

		/* Create the widget. */
		$this->WP_Widget(
			'news-cattags-tabs',				// $this->id_base
			__( 'HYUI: CatTags Tabs', 'hybrid-yui' ),	// $this->name
			$widget_options,				// $this->widget_options
			$control_options				// $this->control_options
		);
	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 *
	 * @since 0.1.0
	 */
	function widget( $sidebar, $instance ) {
		extract( $sidebar );

		/* Output the theme's $before_widget wrapper. */
		echo $before_widget;

		/* If a title was input by the user, display it. */
		if ( !empty( $instance['title'] ) )
			echo $before_title . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $after_title;

		?>
		<div class="ui-tabs">

			<div class="ui-tabs-wrap">

				<ul class="ui-tabs-nav">
					<li><a href="#<?php echo sanitize_html_class( "{$this->id}-1" ); ?>"><?php echo $instance['tags_tab_title']; ?></a></li>
					<li><a href="#<?php echo sanitize_html_class( "{$this->id}-2" ); ?>"><?php echo $instance['cats_tab_title']; ?></a></li>
					</ul><!-- .ui-tabs-nav -->

				<div id="<?php echo sanitize_html_class( "{$this->id}-1" ); ?>" class="ui-tabs-panel">

  <?php
			  $noOfTags = 3; 
			  $noOfPosts = 3;      
			  $cloudRight = get_tags("orderby=count&order=DESC&number=$noOfTags");
			  foreach((array)$cloudRight as $tagRight) : ?>
			<div class="yui-cms-accordion multiple fade fixIE" id="mylist-first-accordion">	
				  <?php        
				  $postsRight = new WP_Query();
				  $postsRight->query("tag={$tagRight->slug}&showposts=$noOfPosts");        
				  ?>            
				  <?php if ( $postsRight->have_posts() ) :?>		  
						<div class="yui-cms-item" id="mylist-first-element"><h3 style="text-transform:capitalize;"><a href="#" class="accordionRemoveItem action" title="click to remove">&nbsp;</a><a href="#" class="accordionToggleItem">&raquo;&nbsp;<?php echo $tagRight->name ?></a></h3>
					  <div class="bd">
					  <div class="fixed">
					<?php while ( $postsRight->have_posts() ) : $postsRight->the_post(); ?>
					 <ul><li><?php echo do_shortcode('[entry-published]'); ?> - <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
					  </ul>	
					  <?php endwhile;?> </div></div> 
				  <?php endif; ?></div> 	  
			  <?php unset($postsRight); echo '</div>';endforeach; ?>

				</div><!-- .ui-tabs-panel -->

				<div id="<?php echo sanitize_html_class( "{$this->id}-2" ); ?>" class="ui-tabs-panel">

					<?php $loop = new WP_Query( array( 'post_type' => $instance['post_type'], 'ignore_sticky_posts' => true, 'posts_per_page' => intval( $instance['posts_per_page'] ),  'orderby' => 'comment_count' ) ); ?>

					<?php if ( $loop->have_posts() ) : ?>

						<ul class="xoxo">

						<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
							<?php the_title( '<li><a href="' . get_permalink() . '" title="' . the_title_attribute( 'echo=0' ) . '">', '</a>' ); ?>
							<span class="count view-count"><?php printf( __( '(%s)', 'hybrid-yui' ), get_comments_number() ); ?></span>
							</li>
						<?php endwhile; ?>

						</ul>

					<?php endif; wp_reset_query(); ?>

				</div><!-- .ui-tabs-panel -->

				<div id="poptabs3"> 
			
			  ssssssssssss
 				</div><!-- .ui-tabs-panel -->
				
			</div><!-- .ui-tabs-wrap -->

		</div><!-- .ui-tabs --> <?php

		/* Close the theme's widget wrapper. */
		echo $after_widget;
	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 *
	 * @since 0.1.0
	 */
	function update( $new_instance, $old_instance ) {

		$instance = $new_instance;

		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['tags_tab_title'] = strip_tags( $new_instance['tags_tab_title'] );
		$instance['cats_tab_title'] = strip_tags( $new_instance['cats_tab_title'] );
		$instance['posts_per_page'] = intval( $new_instance['posts_per_page'] );
		$instance['post_type'] = strip_tags( $new_instance['post_type'] );

		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 *
	 * @since 0.1.0
	 */
	function form( $instance ) {

		/* Set up the default form values. */
		$defaults = array(
			'title' => 				esc_attr__( 'Most', 'hybrid-yui' ),
			'posts_per_page' => 		3,
			'post_type' => 			'post',
			'tags_tab_title' => 		esc_attr__( 'Tagged', 'hybrid-yui' ),
			'cats_tab_title' => 	esc_attr__( 'Category', 'hybrid-yui' )
		);

		/* Merge the user-selected arguments with the defaults. */
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<div class="hybrid-widget-controls columns-1">
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'hybrid-yui' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'post_type' ); ?>"><?php _e( 'Post Type:', 'hybrid-yui' ); ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id( 'post_type' ); ?>" name="<?php echo $this->get_field_name( 'post_type' ); ?>">
			<?php foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $post_type ) {
				if ( post_type_supports( $post_type->name, 'entry-views' ) ) { ?>
					<option value="<?php echo esc_attr( $post_type->name ); ?>" <?php selected( $instance['post_type'], $post_type->name ); ?>><?php echo esc_html( $post_type->labels->singular_name ); ?></option>
				<?php }
			} ?>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'posts_per_page' ); ?>"><?php _e( 'Limit:', 'hybrid-yui' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'posts_per_page' ); ?>" name="<?php echo $this->get_field_name( 'posts_per_page' ); ?>" value="<?php echo esc_attr( $instance['posts_per_page'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'tags_tab_title' ); ?>"><?php _e( 'Tags Tab Title:', 'hybrid-yui' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'tags_tab_title' ); ?>" name="<?php echo $this->get_field_name( 'tags_tab_title' ); ?>" value="<?php echo esc_attr( $instance['tags_tab_title'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'cats_tab_title' ); ?>"><?php _e( 'Comments Tab Title:', 'hybrid-yui' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'cats_tab_title' ); ?>" name="<?php echo $this->get_field_name( 'cats_tab_title' ); ?>" value="<?php echo esc_attr( $instance['cats_tab_title'] ); ?>" />
		</p>
		</div>
		<div style="clear:both;">&nbsp;</div>
	<?php
	}
}

?>