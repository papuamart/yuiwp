<?php

class YUIWP_Recent_Tags extends WP_Widget {
	function YUIWP_Recent_Tags() {
		$this->WP_Widget( false, __('YUIWP Recent Tags', 'p2'), array('description' => __('The tags from the latest posts.', 'p2')));
		$this->default_num_to_show = 35;
	}
	
	function form( $instance ) {
		$title = esc_attr( $instance['title'] );
		$title_id = $this->get_field_id('title');
		$title_name = $this->get_field_name('title');
		$num_to_show = esc_attr( $instance['num_to_show'] );
		$num_to_show_id = $this->get_field_id('num_to_show');
		$num_to_show_name = $this->get_field_name('num_to_show');
		
?>
	<p>
		<label for="<?php echo $title_id ?>"><?php _e('Title:', 'p2') ?> 
			<input type="text" class="widefat" id="<?php echo $title_id ?>" name="<?php echo $title_name ?>"
				value="<?php echo $title; ?>" />
		</label>
	</p>
	<p>
		<label for="<?php echo $num_to_show_id ?>"><?php _e('Number of tags to show:', 'p2') ?> 
			<input type="text" class="widefat" id="<?php echo $num_to_show_id ?>" name="<?php echo $num_to_show_name ?>"
				value="<?php echo $num_to_show; ?>" />
		</label>
	</p>
<?php
	}
	
	function update( $new_instance, $old_instance ) {
		$new_instance['num_to_show'] = (int)$new_instance['num_to_show']? (int)$new_instance['num_to_show'] : $this->default_num_to_show;
		return $new_instance;
	}
	
	function widget( $args, $instance ) {
		extract( $args );
		
		$title = (isset( $instance['title'] ) && $instance['title'])? $instance['title'] : __('Recent tags', 'p2');
		$num_to_show = (isset( $instance['num_to_show'] ) && (int)$instance['num_to_show'])? (int)$instance['num_to_show'] : $this->default_num_to_show;
		
		$recent_tags = $this->recent_tags( $num_to_show );
		
		echo $before_widget . $before_title . esc_html( $title ) . $after_title;
		echo "\t<ul>\n";

		foreach( $recent_tags as $recent ):
	?>
		<li>
			<a class="rss" href="<?php echo esc_url( $recent['feed_link'] ); ?>">RSS</a>&nbsp;
			<a href="<?php echo esc_url( $recent['link'] ); ?>"><?php echo esc_html( $recent['tag']->name ); ?></a>&nbsp;
			(&nbsp;<?php echo number_format_i18n( $recent['tag']->count ); ?>&nbsp;)
		</li>
	<?php
	    endforeach;
	?>
	</ul>
	<p>
		<a class="allrss" href="<?php bloginfo( 'rss2_url' ); ?>"><?php _e('All Updates RSS', 'p2'); ?></a>
	</p>
	<?php
		echo $after_widget;
	}
	
	function recent_tags( $num_to_show ) {
		$cache = wp_cache_get( 'p2_recent_tags', 'widget' );
		if ( !is_array( $cache ) ) {
			$cache = array();
		}
		if ( isset( $cache[$num_to_show] ) && is_array( $cache[$num_to_show] ) ) {
			return $cache[$num_to_show];
		}
		
		$all_tags = (array) get_tags( array( 'get' => 'all' ) );

		$post_ids_and_tags = array();
		foreach( $all_tags as $tag ) {
			if( $tag->count < 1 )
				continue;
			$recent_post_id = max( get_objects_in_term( $tag->term_id, 'post_tag' ) );
			$post_ids_and_tags[] = array( 'post_id' => $recent_post_id, 'tag' => $tag );
		}

		usort( $post_ids_and_tags, create_function('$a, $b', 'return $b["post_id"] - $a["post_id"];') );

		$post_ids_and_tags = array_slice( $post_ids_and_tags, 0, $num_to_show );
		
		$recent_tags = array();
		foreach( $post_ids_and_tags as $v ) {
			$recent_tags[] = array(
				'tag' => $v['tag'],
				'link' => get_tag_link( $v['tag']->term_id ),
				'feed_link' => get_tag_feed_link( $v['tag']->term_id ),
			);
		}
		$cache[$num_to_show] = $recent_tags;
		wp_cache_add( 'p2_recent_tags', $cache, 'widget' );
		return $recent_tags;
	}
	
}

register_widget('YUIWP_Recent_Tags');

///
function prologue_init() {
}
add_action( 'init', 'prologue_init' );
function prologue_recent_projects_widget( $args ) {
	extract( $args );
	$options = get_option( 'prologue_recent_projects' );
	$title = empty( $options['title'] ) ? __( 'Arsip & RSS Tag' , 'papuamerdeka') : $options['title'];
	$num_to_show = empty( $options['num_to_show'] ) ? 35 : $options['num_to_show'];

	$num_to_show = (int) $num_to_show;

	$before = $before_widget;
	$before .= $before_title . wp_specialchars( $title ) . $after_title;

	$after = $after_widget;

	echo prologue_recent_projects( $num_to_show, $before, $after );
}
function prologue_recent_projects( $num_to_show = 35, $before = '', $after = '' ) {
	$cache = wp_cache_get( 'prologue_theme_tag_list', '' );
	if( !empty( $cache[$num_to_show] ) ) {
		$recent_tags = $cache[$num_to_show];
	} else {
		$all_tags = (array) get_tags( array( 'get' => 'all' ) );

		$recent_tags = array();
		
		foreach( $all_tags as $tag ) {
			if( $tag->count < 1 )
				continue;

			$tag_posts = get_objects_in_term( $tag->term_id, 'post_tag' );
			$recent_post_id = max( $tag_posts );
			$recent_tags[$tag->term_id] = $recent_post_id;
		}
		arsort( $recent_tags );
		$num_tags = count( $recent_tags );
		if( $num_tags > $num_to_show ) {
			$reduce_by = (int) $num_tags - $num_to_show;
			for( $i = 0; $i < $reduce_by; $i++ ) {
				array_pop( $recent_tags );
			}}
		wp_cache_set( 'prologue_theme_tag_list', array( $num_to_show => $recent_tags ) );
	}
	echo $before;
	echo "<ul class=listing>\n";
	foreach( $recent_tags as $term_id => $post_id ) {
		$tag = get_term( $term_id, 'post_tag' );
		$tag_link = get_tag_link( $tag->term_id );
?>
<li>
<a class="rss" href="<?php echo get_tag_feed_link( $tag->term_id ); ?>">RSS</a>&nbsp;<a href="<?php echo $tag_link; ?>"><?php echo wp_specialchars( $tag->name ); ?></a>&nbsp;(&nbsp;<?php echo number_format_i18n( $tag->count ); ?>&nbsp;)
</li>
<?php
    } // foreach $recent_tags
?>
	</ul>
<p><a class="allrss" href="<?php bloginfo( 'rss2_url' ); ?>"><?php _e('All Updates RSS', 'papuamerdeka'); ?></a></p>
<?php
	echo $after;
}
function prologue_flush_tag_cache() {
	wp_cache_delete( 'prologue_theme_tag_list' );
}
add_action( 'save_post', 'prologue_flush_tag_cache' );
function prologue_recent_projects_control() {
	$options = $newoptions = get_option( 'prologue_recent_projects' );

	if( $_POST['prologue_submit'] ) {
		$newoptions['title'] = strip_tags( stripslashes( $_POST['prologue_title'] ) );
		$newoptions['num_to_show'] = (int) strip_tags( stripslashes( $_POST['prologue_num_to_show'] ) );
	}
	if( $options != $newoptions ) {
		$options = $newoptions;
		update_option( 'prologue_recent_projects', $options );
	}
	$title = $options['title'];
	$num_to_show = (int) $options['num_to_show'];
?>
<input type="hidden" name="prologue_submit" id="prologue_submit" value="1" />
<p><label for="prologue_title"><?php _e('Title:', 'papuamerdeka') ?> 
<input type="text" class="widefat" id="prologue_title" name="prologue_title" value="<?php echo attribute_escape($title); ?>" />
</label></p>
<p><label for="prologue_num_to_show"><?php _e('Num of tags to show:', 'papuamerdeka') ?> 
<input type="text" class="widefat" id="prologue_num_to_show" name="prologue_num_to_show" value="<?php echo $num_to_show ?>" />
</label></p>
<?php
}
wp_register_sidebar_widget( 'prologue_recent_projects_widget', __( 'Arsip & RSS Tag' , 'papuamerdeka'), 'prologue_recent_projects_widget' );
wp_register_widget_control( 'prologue_recent_projects_widget', __( 'Arsip & RSS Tag' , 'papuamerdeka'), 'prologue_recent_projects_control' );

function prologue_get_avatar( $user_id, $email, $size ) {
	if ( $user_id )
		return get_avatar( $user_id, $size );
	else
		return get_avatar( $email, $size );
}

function prologue_ajax_tag_search() {
	global $wpdb;
	$s = $_GET['q'];
	if ( false !== strpos( $s, ',' ) ) {
		$s = explode( ',', $s );
		$s = $s[count( $s ) - 1];
	}
	$s = trim( $s );
	if ( strlen( $s ) < 2 )
		die; // require 2 chars for matching
	
	$results = $wpdb->get_col( "SELECT t.name FROM $wpdb->term_taxonomy AS tt INNER JOIN $wpdb->terms AS t ON tt.term_id = t.term_id WHERE tt.taxonomy = 'post_tag' AND t.name LIKE ('%". like_escape( $wpdb->escape( $s ) ) . "%')" );
	echo join( $results, "\n" );
	exit;
}
function prologue_latest_posts() {
	$load_time = $_GET['load_time'];
	$frontpage = $_GET['frontpage'];
	$num_posts = 10; //max amount of posts to load
	$number_of_new_posts = 0;
	$prologue_query = new WP_Query('showposts=' . $num_posts . '&post_status=publish');
	ob_start();
	while ($prologue_query->have_posts()) : $prologue_query->the_post();
	    $current_user_id = get_the_author_ID( );
		if ( get_gmt_from_date( get_the_time( 'Y-m-d H:i:s' ) ) <=  $load_time ) continue;
		$number_of_new_posts++;
		if ( $frontpage ) {
}
    endwhile;
    $posts_html = ob_get_contents();
    ob_end_clean();
    if ( $number_of_new_posts == 0 ) {
    	echo '0';
    } else {
    	$json_data = array("numberofnewposts" =>$number_of_new_posts, "html" => $posts_html, "lastposttime" => gmdate( 'Y-m-d H:i:s' ));
    	echo json_encode( $json_data );
    }
    exit;
}
//Search related Functions
function search_comments_distinct( $distinct ) {
	global $wp_query;
	if (!empty($wp_query->query_vars['s'])) {
		return 'DISTINCT';
	}
}
add_filter('posts_distinct', 'search_comments_distinct');

function search_comments_where( $where ) {
	global $wp_query, $wpdb;
	if (!empty($wp_query->query_vars['s'])) {
			$or = " OR ( comment_post_ID = ".$wpdb->posts . ".ID  AND comment_approved =  '1' AND comment_content LIKE '%" . like_escape( $wpdb->escape($wp_query->query_vars['s'] ) ) . "%') ";
  			$where = preg_replace( "/\bor\b/i", $or." OR", $where, 1 );
	}
	return $where;
}
add_filter('posts_where', 'search_comments_where');

function search_comments_join( $join ) {
	global $wp_query, $wpdb, $request;
	if (!empty($wp_query->query_vars['s'])) {
		$join .= " LEFT JOIN $wpdb->comments ON ( comment_post_ID = ID  AND comment_approved =  '1')";
	}
	return $join;
}
add_filter('posts_join', 'search_comments_join');

function get_search_query_terms() {
	$search = get_query_var('s');
	$search_terms = get_query_var('search_terms');
	if ( !empty($search_terms) ) {
		return $search_terms;
	} else if ( !empty($search) ) {
		return array($search);
	}
	return array();
}
function hilite( $text ) {
	$query_terms = array_filter( array_map('trim', get_search_query_terms() ) );
	foreach ( $query_terms as $term ) {
	    $term = preg_quote( $term, '/' );
		if ( !preg_match( '/<.+>/', $text ) ) {
			$text = preg_replace( '/(\b'.$term.'\b)/i','<span class="hilite">$1</span>', $text );
		} else {
			$text = preg_replace( '/(?<=>)([^<]+)?(\b'.$term.'\b)/i','$1<span class="hilite">$2</span>', $text );
		}
	}
	return $text;
}
function hilite_tags( $tags ) {
	$query_terms = array_filter( array_map('trim', get_search_query_terms() ) );
	// tags are kept escaped in the db
	$query_terms = array_map( 'wp_specialchars', $query_terms );
	foreach( array_filter((array)$tags) as $tag ) {
	    if ( in_array( trim($tag->name), $query_terms ) ) {
	        $tag->name ="<span class='hilite'>". $tag->name . "</span>";
	    }
	}
	return $tags;
}
// Highlight text and comments:
add_filter('get_the_tags', 'hilite_tags');
?>