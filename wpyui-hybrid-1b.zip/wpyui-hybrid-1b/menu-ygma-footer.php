<?php
/**
 * YGMA Menu Template
 *
 * Displays the Posttypes Menu if it has active menu items.
 *
 * @package News
 * @subpackage Template
 */

if ( has_nav_menu( 'ygma-menu' ) ) : ?>

	<div id="ygma-footer" class="menu-container">		

			<?php do_atomic( 'before_ygma_menu' ); // Before subsidiary menu hook ?>

		<?php wp_nav_menu( array( 'theme_location' => 'ygma-menu', 'container_class' => 'menu', 'menu_class' => '', 'fallback_cb' => '' ) ); ?>
			
			<?php do_atomic( 'after_ygma_menu' ); // After subsidiary menu hook ?>

	</div><!-- #ygma-menu  .menu-container -->
	
<?php else : ?>

<div id="ygma" class="menu-container">	

			<?php do_atomic( 'before_ygma_menu' ); // Before subsidiary menu hook ?>

<div id="ygmacx">
                    <div id="ygmatop">

	     <div class="sitesearch" style="float:left;">
<? // TOP SIDEBAR ?>
<!-- Site Search Google -->
<form method="get" action="http://www.google.com/custom" target="_top">
<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/google_logo.gif" width="40" height="13" border="0" alt="Google" align="middle"></img>
<input type="hidden" name="domains" value="<?php echo trailingslashit( home_url() ); ?>"></input>
<input type="text" title="Pilih Katakunci untuk Mencari berita dalam situs ini yang telah disimpan di Google ATAU juga bisa cari berbagai berita langsung di Google. Silahkan pilih TOMBOL Web atau di situs ini..." class="yui-tip" name="q" size="31" maxlength="2355" value=""></input>
<input name="sa" type="submit" class="buttons" id="yui-search-button" value='Search' /> 
<input type="radio" name="sitesearch" value="" ></input>
<font size="-1" color="#000"><?php _e( 'the web', hybrid_get_textdomain() ); ?></font>
&nbsp;&nbsp;
<input type="radio" name="sitesearch" value="<?php echo trailingslashit( home_url() ); ?>" checked="checked"></input>
<font size="-1" color="#000"><?php _e( 'In This Site', hybrid_get_textdomain() ); ?> </font>
<input type="hidden" name="client" value="005979918960197945866:5hriyk8iv94"></input>
<input type="hidden" name="forid" value="1"></input>
<input type="hidden" name="ie" value="ISO-8859-1"></input>
<input type="hidden" name="oe" value="ISO-8859-1"></input>
<input type="hidden" name="cof" value="GALT:#008000;GL:1;DIV:#336699;VLC:663399;AH:center;BGC:FFFFFF;LBGC:336699;ALC:0000FF;LC:0000FF;T:000000;GFNT:0000FF;GIMP:0000FF;FORID:1"></input>
<input type="hidden" name="hl" value="en"></input>
</form><!-- SiteSearch Google -->
<? // END TOP SIDEBAR ?>
</div>
		
	<div id="ygmafrm">

<!-- Yahoo! Search --><div style="float:right;">
<form method="get" action="http://search.yahoo.com/search">
<div><a href="http://search.yahoo.com/">
<img src="http://us.i1.yimg.com/us.yimg.com/i/us/search/ysan/ysanlogo.gif" width="50" height="20" align="left" border="0" /></a>
<input name="p" type="text" style="font-size:14px;" class="yui-tip" title="Silahkan pilih 'the Web' untuk cari di Yahoo!.com atau 'this Site' untuk cari di situs ini ...">
<input name="fr" value="yscpb" type="hidden">
<input class="buttons" value="Search" type="submit">
<span style="font-family:arial,helvetica;"><input name="vs" style="vertical-align: middle;" value="" checked="checked" type="radio"><?php _e( 'the web', hybrid_get_textdomain() ); ?> <input name="vs" style="vertical-align: middle;" value="<?php echo trailingslashit( home_url() ); ?>" type="radio"><?php _e( 'In This Site', hybrid_get_textdomain() ); ?> </span></div>
</form></div>
<!-- End Yahoo! Search -->
                        </div>
                   </div>
            </div>
            </div>

			<?php do_atomic( 'after_ygma_menu' ); // After subsidiary menu hook ?>

<?php endif; ?>