<?php
/**
 * Header Template
 *
 * The header template is generally used on every page of your site. Nearly all other
 * templates call it somewhere near the top of the file. It is used mostly as an opening
 * wrapper, which is closed with the footer.php file. It also executes key functions needed
 * by the theme, child themes, and plugins. 
 *
 * @package Hybrid
 * @subpackage Template
 */
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
<title><?php hybrid_document_title(); ?></title>
 <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>" type="text/css" media="all" />
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon.ico" />
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<meta http-equiv="X-UA-Compatible" content="IE=9" />

<?php do_atomic( 'head' ); // @deprecated 0.9.0. Use 'wp_head'. ?>

<?php wp_head(); // wp_head ?>

</head>
	
<?php flush(); // flush the stylesheets and javascripts ?>

<body id="cms-story" class="yui3-skin-mine yui-skin-sam <?php hybrid_body_class(); ?>">

<?php do_atomic( 'before_html' ); // hybrid_before_html ?>

<?php if (current_theme_supports( 'dispatch-multicolour' ) ) { echo '<div id="pmnewscss">';
include ( 'library/content/dispatch-multicolour.html' ); } ?>

<div id="header-container">

		<?php do_atomic( 'before_header' ); // hybrid_before_header ?>

<?php if (current_theme_supports('custom-header') )  { ?>	
		
	<header id="hd" class="hd">

		<div id="header" class="yui-g">
		
		<div id="branding" class="yui-u first">

			<?php do_atomic( 'header' ); // hybrid_header ?>	

			</div><!-- .yui-u first -->

	<div class="yui-u">
   <div class="tagsmyAccordion1" style="width:100%;"> 
	<div class="yui-cms-accordion multiple fade fixIE" id="mylist-first-accordion">			  
              	<div class="yui-cms-item selected" id="mylist-first-element">
				<div style="text-transform:capitalize;font-size:90%;"><a href="#" class="accordionRemoveItem action" title="click to remove">&nbsp;</a> 
		      <a href="#" class="accordionToggleItem action" title="click to expand">&nbsp;</a> &raquo;&nbsp;
 				<?php echo short_title(); ?>	
			  </div>
              <div class="bd">
              <div class="fixed">
			  
			<?php do_atomic( 'close_header' ); // hybrid_header ?>	

				</div><!-- .fixed -->
			</div><!-- .bd -->
		</div><!-- .yui-cms-item -->
		</div><!-- .yui-cms-accordion --> 
	</div><!-- .tagsmyAccordion1 --> 

	</div><!-- .yui-u -->
	
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php if ( get_header_image() ) echo '<img class="header-image" src="' . get_header_image() . '" alt="" />'; ?>
		</a>		

		</div><!-- .yui-g -->

	</header><!-- #header-container -->
 
<?php } else { ?>
 		
	<header id="hd" class="hd">

	<div id="header" class="yui-g">

		<div id="branding" class="yui-u first">

			<?php do_atomic( 'header' ); // hybrid_header ?>			

		</div><!-- #header -->
		
			<div class="yui-u">
 
			<?php do_atomic( 'close_header' ); // hybrid_header ?>	
	
	</div><!-- class="yui-u" -->
	
	</div><!-- yui-gb -->

		</header><!-- #header-container -->
	
<?php } ?>

	<?php do_atomic( 'after_header' ); // hybrid_after_header ?>

	</div><!-- #header-container -->

	<?php do_atomic( 'before_main' ); // hybrid_after_header ?>

		<!-- ENTERING BODY: follow some template_parts to properly display grids-->

     <section id="main" class="panels">	 

  <div id="bd" role="main" class="yui-cms-accordion multiple fade fixIE">  

<?php
/**
 * Before Container Utility
 *
 * This template displays widgets for Utility: Before Content.
 * If no widgets are added, nothing is displayed.
 * @link http://themehybrid.com/themes/hybrid/widget-areas
 *
 * @package Hybrid
 * @subpackage Template
 */
?>

<?php /* If this is home page and orthers */ if (is_attachment()
 || is_page_template('page-front-page.php') 
 || is_page_template('page-pmnews-home.php') 
 || is_page('Archives') 
 || is_page('facebook') 
 || is_page('forum') 
 || is_page('Category Archives') 
 || is_page('google-archive') 
 || is_page('yui-portal') 
 || is_singular('video') 
 || is_singular('slideshow') 
 || is_attachment('image') ) { ?> 
 
   <div id="yui-main" class="body-border">
	   <div>
	   <div id="dynamic-area">
	   <div>

<?php /* If this is a page template home */ } elseif (is_page_template('page-home.php') ) { ?>

   <div id="yui-main" class="body-border">

<div class="yui-b">	

<!--?php if (!is_paged()) include( get_stylesheet_directory() . '/library/home/yui-dynamic-roundups.html' ); // Loads the loop-meta.php template. ?-->

 <div id="dynamic-area" class="yui-gc">	 

  <div class="yui-u first">

<?php /* If this is a page and is singular post */ } elseif (is_singular()) { ?>

   <div id="yui-main" class="body-border">

<div class="yui-b">	

<div id="dynamic-area">	
	
<div>
	   <?php } else { ?>
	   
   <div id="yui-main" class="body-border">

<div class="yui-b">	

	<div  id="dynamic-area" class="yui-gd">

    <div class="yui-u first">

<?php get_sidebar( 'secondary' ); // Loads the sidebar-secondary.php template. ?>	
	  
	  </div><!-- .yui-u first-->
		
    <div class="yui-u">
	<!-- YOUR DATA GOES HERE -->
	<?php } ?>	 
	
    <!--script type="text/javascript">
    //configuring the loading mask
	YAHOO.widget.Loading.config({
	  effect: true,
	  opacity: 0.7
	});
  </script>
	<div id="yui-cms-loading">
    <div id="yui-cms-float">
        Loading, please wait...
    </div>
</div-->