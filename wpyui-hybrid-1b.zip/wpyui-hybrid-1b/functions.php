<?php
/**
 * This is your child theme functions file.  In general, most PHP customizations should be placed within this
 * file.  Sometimes, you may have to overwrite a template file.  However, you should consult the theme
 * documentation and support forums before making a decision.  In most cases, what you want to accomplish
 * can be done from this file alone.  This isn't a foreign practice introduced by parent/child themes.  This is
 * how WordPress works.  By utilizing the functions.php file, you are both future-proofing your site and using
 * a general best practice for coding.
 *
 * All style/design changes should take place within your style.css file, not this one.
 *
 * The functions file can be your best friend or your worst enemy.  Always double-check your code to make
 * sure that you close everything that you open and that it works before uploading it to a live site.
 *
 * @package yahoowp
 * @subpackage Functions
 */
/* Load PMNews Extra theme framework. */
require_once( trailingslashit( get_stylesheet_directory() ) . 'library/yahoowph.php' );
new YahooWPHybrid();

require_once( trailingslashit( get_stylesheet_directory() ) . '/library/admin/tabs-functions.php');

// adds the child theme setup function to the 'after_setup_theme' hook
add_action('after_setup_theme', 'yahoo_wp_theme_setup', 11);
add_action( 'after_setup_theme', 'yui_grids_after_setup_theme', 11 );

/**
 * Setup function.  All child themes should run their setup within this function.  The idea is to add/remove
 * filters and actions after the parent theme has been set up.  This function provides you that opportunity.
 *
 * @since 0.1.0
 */
function yahoo_wp_theme_setup()
{
    // get the theme prefix
    $prefix = hybrid_get_prefix();	

	/* Load any translation files for the user. */
	load_child_theme_textdomain( 'yahoowph', get_stylesheet_directory() );	
 
  /* Add theme support for core framework features. */
    add_theme_support( 'hybrid-core-menus', array( 'primary', 'secondary', 'subsidiary' ) );
    add_theme_support( 'hybrid-core-sidebars', array( 'primary', 'secondary', 'subsidiary' ) );
    add_theme_support( 'hybrid-core-widgets' );
    add_theme_support( 'hybrid-core-shortcodes' );
    add_theme_support( 'hybrid-core-theme-settings', array( 'about', 'footer' ) );
    add_theme_support( 'hybrid-core-drop-downs' );
    add_theme_support( 'hybrid-core-template-hierarchy' );

    /* Add theme support for framework extensions. */
    add_theme_support( 'theme-layouts', array( '1c', '2c-l', '2c-r' ) );
    add_theme_support( 'post-stylesheets' );
    add_theme_support( 'dev-stylesheet' );
    add_theme_support( 'loop-pagination' );
    add_theme_support( 'get-the-image' );
    add_theme_support( 'breadcrumb-trail' );
    add_theme_support( 'cleaner-gallery' );
    add_theme_support( 'entry-views' );

    /* Add theme support for WordPress features. */
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'post-formats', array( 'image', 'gallery' ) );

    /* Add support for WordPress custom background. */
    add_theme_support(
        'custom-background',
        array(
            'default-image' => trailingslashit( get_stylesheet_directory_uri() ) . 'images/graphy.png',
            'wp-head-callback' => 'yahoowp_custom_background_callback'
        )
    );

    /* Add support for WordPress custom header image. */
    add_theme_support(
        'custom-header',
        array(
            'wp-head-callback' => '__return_false',
            'admin-head-callback' => '__return_false',
            'header-text' => false,
            'default-image' => 'remove-header',
            'width' => 960,
            'height' => 210
        )
    );
	/* Add featured-header support. */
		if ( current_theme_supports( 'custom-header' ) ) {
	require_once( trailingslashit( get_stylesheet_directory() ) . 'library/admin/featured-header.php' );
		}
		
    add_theme_support( 'popular-inthis' ); /* include 'calsses/widget-papua.php' */
    add_theme_support( 'front-page-template' ); /* include 'calsses/widget-papua.php' */
    add_theme_support( 'hybrid-yui-core-sidebars' ); /* include 'calsses/widget-papua.php' */
  //  add_theme_support( 'dispatch-multicolour' ); /* include 'calsses/widget-papua.php' */
   // add_theme_support( 'news-ticker' ); /* include 'calsses/widget-papua.php' */
	
	/* Add Custom Field Series */
	if ( current_theme_supports( 'custom-field-series' ) ) {
		add_action( "{$prefix}_after_singular", 'custom_field_series' );
	}
	
    // register and enqueue needed styles for yui css grids and YUI js
    add_action('wp_enqueue_scripts', 'yahoowp_init', 11 );

	/* Register additional menus. */
	add_action( 'init', 'hybrid_yui_news_register_menus', 12 );
	
	/* Perform specific functions for the front page template. */
	add_action( 'template_redirect', 'hybrid_yui_news_front_page_template' );
	
	remove_action( "{$prefix}_after_header", 'hybrid_get_primary_menu' );
	add_action( "{$prefix}_before_header", 'hybrid_get_primary_menu' );
	add_action( "{$prefix}_after_header", 'hybrid_get_secondary_menu' );
	add_action( "{$prefix}_after_primary_menu", 'hybrid_yui_news_get_posttypes_menu' );	
	add_action( "{$prefix}_close_header", 'hybrid_get_tags_breadcrumb_menu' );
	add_action( "{$prefix}_after_secondary_menu", 'hybrid_yui_news_get_portfolio_menu' );

	/* Deply YUI CSS Grids layout before starts all */
	add_action( "{$prefix}_before_html", 'hybrid_get_yui_css_grids' );
	add_action( "{$prefix}_before_html", 'hybrid_get_header_ygma_menu' );

	/* Add the header sidebar to the header. */
	add_action( "{$prefix}_header", 'hybrid_yui_news_get_utility_header', 11 );
 
		/* Add a wrapper class for singular videos. */
	add_filter( 'the_content', 'news_video_embed_wrapper', 20 );
	/* Embed width/height defaults. */
	add_filter( 'embed_defaults', 'news_embed_defaults' );
	
    // apply filter to the default theme settings
    add_filter("{$prefix}_default_theme_settings", 'yahoowp_default_theme_settings');

	/* Add the title, byline, and entry meta before and after the entry. */
	remove_action( "{$prefix}_before_entry", 'hybrid_entry_title' );
	add_action( "{$prefix}_before_entry", 'hybrid_news_entry_title' );
	remove_action( "{$prefix}_before_entry", 'hybrid_byline' );
	add_action( "{$prefix}_before_entry", 'news_posted_on' );
	remove_action( "{$prefix}_after_entry", 'hybrid_entry_meta' );	
	add_action( "{$prefix}_after_entry", 'news_posted_in' );	
	add_action( "{$prefix}_before_primary", 'hybrid_child_sidebar_loop_nav' );	

	add_action( "{$prefix}_after_footer", 'hybrid_get_subsidiary_menu' );	
	add_action( "{$prefix}_after_footer", 'hybrid_get_footer_ygma_menu' );	
	add_action( "{$prefix}_after_html", 'hybrid_get_yui_css_grids_ends' );	
	
	/* Add featured-header support. */
	if ( is_admin() )
	/* Set up the theme settings meta box. */
	add_action( 'admin_menu', 'hybrid_yui_news_create_meta_box' );
	
	require_once( trailingslashit( get_stylesheet_directory() ) . 'library/admin/admin.php' );
	
	/* Tag cloud. */
	add_filter( 'wp_tag_cloud', 'news_add_span_to_tag_cloud' );
	add_filter( 'term_links-post_tag', 'news_add_span_to_tag_cloud' );	
		
	/* Save the theme settings meta box settings. */
	add_filter( "sanitize_option_{$prefix}_theme_settings", 'hybrid_yui_news_save_meta_box' );

}

/**
 * Displays the post title.
 *
 * @since 0.5.0
 */
function hybrid_news_entry_title() {
	echo apply_atomic_shortcode( 'entry_title', '[entry-title]' );
	echo '<p class=entry-subtitle>';
	echo apply_atomic_shortcode( 'entry_subtitle', '[entry-subtitle]' );
	echo '</p>';
}

/**
 * Displays the post tags for singular posts.
 * Taken from News theme
 * Theme URI: http://themehybrid.com/themes/news
 * @since 0.1.0
 * @since 2.0 for HybridChild
 */
function news_singular_post_tags() {
	if ( has_tag() )
		echo '<div class="vsep">' . do_shortcode( '[entry-terms type="post_tag" separator=""]' ) . '</div>';
}

/**
 * Wraps tag cloud links with a span for easier background image styling.
 *
 * @todo If anyone can figure out a way to style this without the <span>, we can remove this.
 *
 * @since 0.1.0
 */
function news_add_span_to_tag_cloud( $cloud ) {
	$cloud = preg_replace( "/>(.*?)<\/a>/", "><span>$1</span></a><span class=vsep></span>", $cloud );
	return $cloud;
}

/**
 * Loads the menu-secondary.php template.
 *
 * @since 0.8.0
 * @uses get_template_part() Checks for template in child and parent theme.
 */
function hybrid_get_secondary_menu() {
	get_template_part( 'menu', 'secondary' );
}

/**
 * Loads the menu-subsidiary.php template.
 *
 * @since 0.8.0
 * @uses get_template_part() Checks for template in child and parent theme.
 */
function hybrid_get_subsidiary_menu() {
	get_template_part( 'menu', 'subsidiary' );
}

/**
 * Loads the menu-posttypes.php template, which displays the Secondary Menu.
 *
 * @since 0.3.0
 */
function hybrid_yui_news_get_posttypes_menu() {
get_template_part( 'menu', 'posttypes' );
}

/**
 * Loads the menu-portfolio.php template, which displays the Secondary Menu.
 *
 * @since 0.3.0
 */

function hybrid_yui_news_get_portfolio_menu() {
if ( post_type_exists( 'portfolio_item' ) ) 
	get_template_part( 'menu', 'portfolio' );
}
 	
/**
 * Loads the sidebar-header.php template, which loads the Utility: Header sidebar.
 *
 * @since 0.3.0
 */
function hybrid_yui_news_get_utility_header() {
	get_sidebar( 'header' );
}

/**
 * Loads the 'shortcodes.php' that contains 'entry-tags-breadcrumb' shortcode.
 *
 * @since 0.3.0
 */
function hybrid_get_tags_breadcrumb_menu() {
echo do_shortcode( '[entry-tags-breadcrumb]' ); // live-wire_close_header
 }

/**
 * Loads the oop-nav-sidebar.php template, which displays the Secondary Menu.
 *
 * @since 0.3.0
 */
function hybrid_child_sidebar_loop_nav() {
	locate_template( array( 'loop-nav-sidebar.php', 'loop-nav.php' ), true );
}

/**
 * Loads the menu-ygma.php template.
 *
 */
function hybrid_get_header_ygma_menu() {
	locate_template( array( 'menu-ygma-header.php', 'menu.php' ), true );
}

/**
 * Loads the menu-ygma.php template.
 *
 */
function hybrid_get_footer_ygma_menu() {
	locate_template( array( 'menu-ygma-footer.php', 'menu.php' ), true );
}
 	
/**
 * Registers additional nav menus for use with this theme.
 *
 * @since 0.3.0
 */
function hybrid_yui_news_register_menus() {
	register_nav_menu( 'posttypes', __( 'Post Types Menu', 'hybrid-yui-news' ) );
	register_nav_menu( 'postformats', __( 'Post Formats Menu', 'hybrid-yui-news' ) );
	if ( post_type_exists( 'portfolio_item' ) )
	register_nav_menu( 'portfolio', esc_html__( 'Portfolio Menu', 'hybrid-yui-news' ) );	
}

/**
 * This is a fix for when a user sets a custom background color with no custom background image.  What
 * happens is the theme's background image hides the user-selected background color.  If a user selects a
 * background image, we'll just use the WordPress custom background callback.
 *
 * @since 0.1.0
 * @link http://core.trac.wordpress.org/ticket/16919
 */
function yahoowp_custom_background_callback() {

    /* Get the background image. */
    $image = get_background_image();

    /* If there's an image, just call the normal WordPress callback. We won't do anything here. */
    if ( !empty( $image ) ) {
        _custom_background_cb();
        return;
    }

    /* Get the background color. */
    $color = get_background_color();

    /* If no background color, return. */
    if ( empty( $color ) )
        return;

    /* Use 'background' instead of 'background-color'. */
    $style = "background: #{$color};";

    ?>
<style type="text/css">body.custom-background { <?php echo trim( $style ); ?> }</style>
<?php
}

/* === CPT: PORTFOLIO PLUGIN. === */

	/**
	 * Returns a link to the porfolio item URL if it has been set.
	 *
	 * @since  0.1.0
	 * @access public
	 * @return void
	 */
	function chun_get_portfolio_item_link() {

		$url = get_post_meta( get_the_ID(), 'portfolio_item_url', true );

		if ( !empty( $url ) )
			return '<span class="project-url">' . __( 'Project <abbr title="Uniform Resource Locator">URL</abbr>:', 'chun' ) . ' <a class="portfolio-item-link" href="' . esc_url( $url ) . '">' . $url . '</a></span> ';
	}

/* End CPT: Portfolio section. */

/**
 * Remove the [theme-link] short code from the footer content. It's not allowed two credit links within WP.org.
 *
 * @since 0.1.3
 */
function yahoowp_default_theme_settings($settings)
{
    $settings['footer_insert'] = '<p class="copyright">' . __('Copyright &#169; [the-year] [site-link].', 'yahoowp') . '</p>' . "\n\n" . '<p class="credit">' . __('Powered by [wp-link] and [child-link].', 'yahoowp') . '</p>';
    return $settings;
}

/**
 * Adds JavaScript and CSS to Front Page page template.
 * Also removes the breadcrumb menu.
 *
 * @since 0.3.0
 */
function hybrid_yui_news_front_page_template() {

	/* If we're not looking at the front page template, return. */
	if ( !is_page_template( 'page-front-page.php' ) )
		return;

	/* Load the jQuery Cycle plugin JavaScript and custom JavaScript for it. */
	wp_enqueue_script( 'slider', get_stylesheet_directory_uri() . '/library/js/jquery.cycle.js', array( 'jquery' ), 0.1, true );

	/* Load the front page stylesheet. */
	wp_enqueue_style( 'front-page', get_stylesheet_directory_uri() . '/library/css/front-page.css', false, '0.1', 'screen' );

	/* Remove the breadcrumb trail. */
	add_filter( 'breadcrumb_trail', '__return_false' );
}

/**
 * This function calls 'yui_css_grid_layout' to begin YUI CSS Grids
 *
 * @since 1.0
 */

function hybrid_get_yui_css_grids() { 
 yui_css_grid_layout(); 
}

/**
 * This function closes 'yui_css_grid_layout' to end YUI CSS Grids
 *
 * @since 1.0
 */

function hybrid_get_yui_css_grids_ends() { 
 echo '</div>';
}

/**
 * This is the major hack for implementing YUI CSS Grids
 * Some parts of the hack will also include Yahoo! JS
 *
 * @since 0.1.3
 */

function yui_grids_after_setup_theme()
{
	add_action( 'init', 'pmnews_yui_grids_setup', 11 );
}

/**
 * Tell WordPress to run pmnews_yui_grids() when the 'after_setup_theme' hook is run.
 */
add_action( 'yui_grids_after_setup_theme', 'pmnews_yui_grids_setup' );

/*
* in the future, this function needs to be executed from a separate 'yui-css-grids.php'
* but for now, pmnews does not know how to integrate into hybrid theme.
*/
if ( ! function_exists( 'pmnews_yui_grids_setup' ) ):

/**
 * Styles the header image and text displayed on the blog
 *
 * @since Twenty Eleven 1.0
 */
 
function pmnews_yui_grids_setup() {
function yui_css_grid_color_scheme() {
    $scheme = get_option('yui_css_grid_color_scheme');
    $style = 'red.css';
    if ($scheme) {
        $style = '/css/' . $scheme . '.css';
    }
    $css_link = "<link rel='stylesheet' type='text/css' href=\"" . get_stylesheet_directory_uri() . $style . "\" />" ;
	echo $css_link;
}

function yui_css_grid_layout() {
    $page_layout = '<div id="doc4" class="yui-t6">';
    $page_width = get_option('yui_css_grid_page_width');
    $layout = get_option('yui_css_grid_layout');
    if (($page_width) && ($layout)) {
        $page_layout = '<div id="' . $page_width . '" class="' . $layout . '" >';
    }
    echo $page_layout;
}
add_action('admin_menu', 'yui_css_grid_add_theme_page');

function yui_css_grid_add_theme_page() {
	if ( isset( $_GET['page'] ) && $_GET['page'] == basename(__FILE__) ) {
		if ( isset( $_REQUEST['action'] ) && 'save' == $_REQUEST['action'] ) {
			check_admin_referer('yui-css-grid-custom');
			$layout = $_REQUEST['layout'];
			$page_width = $_REQUEST['page-width'];
			$color_scheme = $_REQUEST['color-scheme'];
			update_option('yui_css_grid_layout', $layout);
			update_option('yui_css_grid_page_width', $page_width);
			update_option('yui_css_grid_color_scheme', $color_scheme);
			
			//print_r($_REQUEST);
			wp_redirect("themes.php?page=functions.php&saved=true");
			die;
		}    
		add_action('admin_head', 'yui_css_grid_theme_css');
	}
	add_theme_page(__('Set YUI GRIDS'), __('Set YUI GRIDS'), 'edit_themes', basename(__FILE__), 'yui_css_grid_theme_page');
}

function yui_css_grid_theme_css() {
?>
<style type='text/css'>
    label {
        font-weight: bold;
        width: 40px;
        text-align: right;
    }
    
    select {
        margin-bottom: 8px;
        padding-bottom: 8px;
        width: 150px;
        text-align: left
    }
    
	#headwrap {
		text-align: center;
	}
	
	.description {
		margin-top: 16px;
		color: #fff;
	}

	#nonJsForm {
		text-align: center;
	}
	#nonJsForm input.submit, #nonJsForm input.button {
		padding: 0px;
		margin: 0px;
	}
	#advanced {
		text-align: center;
		width: 620px;
	}
</style>
<?php } ?>
<?php
function yui_css_grid_theme_page() {
	if ( isset( $_REQUEST['saved'] ) ) echo '<div id="message" class="updated fade"><p><strong>'.__('Options saved.').'</strong></p></div>';
?>
<div class='wrap'>
	<h2><?php _e('Set YUI Grids Layout and Colour'); ?></h2>
	<div id="yui-css-grid-header">
		<div id="headwrap">
			<div id="header">
				<div id="headerimg">
					<h1><?php bloginfo('name'); ?></h1>
					<div class="description"><?php bloginfo('description'); ?></div>
					<h3><?php _e('Select Your Layout and Theme Settings:', hybrid_get_textdomain() ); ?></h3>
				</div>
			</div>
		</div>
		<br />
		<div id="nonJsForm">
			<form method="post" action="">
				<?php wp_nonce_field('yui-css-grid-custom'); ?>
				<label><?php _e('Page Width:', hybrid_get_textdomain() ); ?></label>
				<select id='page-width' name='page-width'>
<?php
    $widths = array("doc4" => "974px Centered", 
               "doc2" => "950px Centered",
               "doc"  => "750px Centered",
               "doc3" => "100% Fluid",
               "doc-custom" => "Custom Width");
    $current_width = get_option('yui_css_grid_page_width');
    foreach ($widths as $k => $v) {
        $selected = '';
        if ($k === $current_width) { 
            $selected = 'selected="selected"'; 
        };
        echo "<option value='" . $k . "' " . $selected . ">" . $v . "</option>";    
    }
?>				
				</select>&nbsp;&nbsp;<br/>
				<label><?php _e('Page Layout:', hybrid_get_textdomain() ); ?></label>
    			<select id='layout' name='layout'>
<?php
    $layouts = array("yui-t1" => "L+L, L Fixed 160px, R Flexible: 180px-240px", 
                    "yui-t2" => "L+L, L Fixed 240px, R Flexible: 180px-180px ",
                    "yui-t3" => "L+L, L Fixed 300px, R Flexible: 160px-180px",
                    "yui-t4" => "L+R, Inner Smaller, L 240px-300px, Outer Fixed 180px",
                    "yui-t5" => "L+R , Inner Flexible 160px-240px, Outer Fixed 240px",
                    "yui-t6" => "L+R, Inner Fixed 180px, Outer Fixed 300px");
    $current_layout = get_option('yui_css_grid_layout');
    foreach ($layouts as $k => $v) {
        $selected = '';
        if ($k === $current_layout) { 
            $selected = 'selected="selected"'; 
        };
        echo "<option value='" . $k . "' " . $selected . ">" . $v . "</option>";    
    }
?>				
	</select>&nbsp;&nbsp;<br/>
	<label><?php _e('Color Scheme:', hybrid_get_textdomain() ); ?></label>
	<select id='color-scheme' name='color-scheme'>
<?php
    $schemes = array("dark_blue" => "Dark Blue", 
                     "fbook" => "FBook",
                     "green" => "Green",
                     "greenish" => "Greenish",
                     "orange" => "Orange",
                     "purple" => "Purple",
                     "red" => "Red",
                     "tan_blue" => "Tan Blue",
                     "custom" => "Custom");
    $current_scheme = get_option('yui_css_grid_color_scheme');
    foreach ($schemes as $k => $v) {
        $selected = '';
        if ($k === $current_scheme) { 
            $selected = 'selected="selected"'; 
        };
        echo "<option value='" . $k . "' " . $selected . ">" . $v . "</option>";    
    }
?>				
    </select>&nbsp;&nbsp;
    <input type="hidden" name="action" value="save" />
	<br/>
	<p><input type="submit" name="defaults" value="Save Settings" /></p>
	</form>
	<br/>
	</div>
	</div>
	<div style="width:45%;text-algin:left;float:left;">
	<h4><?php _e('default tu theme sizes for one sidebar', hybrid_get_textdomain() ); ?></h4>
<div style="margin: 10px; padding: 10px; background: #fff; border: 1px solid #ddd; overflow:auto; color: #7b11a3; background-color: #f4e8f6; border-color: #d08ee0;">
	<p>doc4-yt1 = left 160px</p><p>
	doc4-yt2 = left 180px</p><p>
	doc4-yt3 = left 300px</p><p>
	</p><p></p>
	doc4-yt4 = right 180px<p>
	doc4-yt5 = right 240px</p><p>
	doc4-yt6 = right 300px	</p>	
	</div>
<h4><?php _e('See the following Default TU YUI CSS GRIDS:', hybrid_get_textdomain() ); ?></h4>		
<textarea name="code" class="HTML">
        <div id="bd"> 
        <div id="yui-main"> 
			<div class="yui-b">		
    </div> <!-- end yui-b -->
   </div> <!-- end yui-main -->
   <!-- enter sidebars here; before closing #bd-->   
   </div> <!-- end bd -->
</textarea>	
<h4><?php _e('See the following Default Two Sidebars YUI Layout:', hybrid_get_textdomain() ); ?></h4>	
<textarea name="code" class="HTML">
	"yui-t1" => "Left Sidebar, 160px", 
     "yui-t2" => "Left Sidebar, 180px",
     "yui-t3" => "Left Sidebar, 300px",
     "yui-t4" => "Right Sidebar, 180px",
     "yui-t5" => "Right Sidebar, 240px",
     "yui-t6" => "Right Sidebar, 300px");
</textarea>	
</div>
<div style="width:45%;text-algin:left;float:right;">
<h2 style="margin: 10px; padding: 10px; background: #fff; border: 1px solid #ddd; overflow:auto; color: #2446ad; background-color: #eaedf7; border-color: #b8c3e4;">See the following Default PMNews YUI CSS GRIDS: with two right sidebars or left and right sidebars in different sizes follwing to YUI GRIDS standard rules:</h2>	
<textarea name="code" class="HTML">
<div id="bd" role="main">
<div id="yui-main">
    <div class="yui-b">	
        <div class="yui-ge">		
            <div class="yui-u first">			
            <!-- main column 
		    // load the main content-->
        </div>
<div class="yui-u">
 <!--?php get_sidebar( 'secondary' ); // hybrid_before_container ?-->   
 </div><!-- .yui-u sidebar-->
	</div><!--<div class="yui-ge">-->
</div><!--  <div class="yui-b" id="dynamic-area">-->
</div><!--<div id="yui-main">-->

<div class="yui-b">
 <!--?php get_sidebar( 'primary' ); // hybrid_before_container ?-->         
</div><!-- .yui-b -->
 <!--?php
/**
 * Footer Template
?-->
</div><!-- #bd -->
</textarea>	

<h3 style="background: #FFB8B8; border: 1px solid #FF8C8C; color: #BF2F2F; text-align: center; padding: 7px; line-height: 20px; font-size: 14px;  margin: 0 auto;"><?php _e('Default TU WodPress Theme Layout for two sidebars', hybrid_get_textdomain() ); ?><br>
<?php _e('Two Right Sidebars and Left-Right Sidebars', hybrid_get_textdomain() ); ?></h3>
<div style="margin: 10px; padding: 10px; background: #fff; border: 1px solid #ddd; overflow:auto; color: #11a322; background-color: #e8f6e9; border-color: #b2e1b7;">
<p>"yui-t1" => "L+R, L Flexible 160px - 240px, R Flexible 160px - 300px",</p><p>
    "yui-t2" => "L+R, L Fixed 180px - 240px, R Flexible 160px - 300px",</p><p>
    "yui-t3" => "L+R, L Fixed 300px, R Flexible 160px - 240px",</p><p>
    "yui-t4" => "R+R, Inner Flexible 160px-300px, Outer Fixed 180px",</p><p>
    "yui-t5" => "R+R, Inner Flexible 160px - 300px, Outer Fixed 240px",</p><p>
    "yui-t6" => "R+R, Inner Flexible 150px-240px, Outer Fixed 300px");</p>
</div>	

<h3 class="background: #FFB8B8; border: 1px solid #FF8C8C; color: #BF2F2F; text-align: center; padding: 7px; line-height: 20px; font-size: 14px;  margin: 0 auto;"><?php _e('Adapted theme sizes for two sidebars', hybrid_get_textdomain() ); ?><br>
<?php _e('Two Left Sidebars and Left-Right Sidebars', hybrid_get_textdomain() ); ?></h3>
<h4><?php _e('See the following Default TU YUI CSS GRIDS:', hybrid_get_textdomain() ); ?></h4>	
<textarea name="code" class="HTML">
    <div id="bd"> 
   <div id="yui-main">   
    <div class="yui-b">	
     <div class="yui-gc">
       <div class="yui-u first">	
	   </div><!-- end yui-u first -->
     </div> <!-- end yui-gc -->
    </div> <!-- end yui-b -->
   </div> <!-- end yui-main -->
   <!-- enter sidebars here; before closing #bd-->
   </div> <!-- end bd -->
</textarea>	
	</div>
	
		<div style="float:left;width:48%;xalign:center;">
<h3 style=" background: #D1F2F5; border: 1px solid #AFDEE2; color: #38878E; text-align: center; padding: 7px; line-height: 20px; font-size: 14px;  margin: 0 auto;"><?php _e('This theme applies the following YUI GRIDS for the following six layouts:', hybrid_get_textdomain() ); ?></h3>	
<div style="margin: 10px; padding: 10px; background: #fff; border: 1px solid #ddd; overflow:auto; color: #2446ad; background-color: #eaedf7; border-color: #b8c3e4;"><h4><?php _e('YUI GRIDS Layout:', hybrid_get_textdomain() ); ?></h4>
div#doc creates a 750px page width.<p>
div#doc2 creates a 950px page width.</p><p>
div#doc3 creates a 100% page width. (Note that the 100% page width also sets 10px of left and right margin so that content had a bit of breathing room between it and the browser chrome.)</p><p>
div#doc4 creates a 974px page width, and is a new addition to Grids in YUI version 2.3.0.</p><p>
</p><p>	
yui-t1 – Two columns, narrow on left, 160px</p><p>
.yui-t2 – Two columns, narrow on left, 180px</p><p>
.yui-t3 – Two columns, narrow on left, 300px</p><p>
.yui-t4 – Two columns, narrow on right, 180px</p><p>
.yui-t5 – Two columns, narrow on right, 240px</p><p>
.yui-t6 – Two columns, narrow on right, 300px</p><p>
=================</p><p>
ui-gb : Takes 3 units and divides equally</p><p>
yui-gc : Takes 2 units and divides as 2/3 and 1/3</p><p>
yui-gd : Takes 2 units and divides as 1/3 and 2/3</p><p>
yui-ge : Takes 2 units and divides as 3/4 and 1/4</p><p>
yui-gf : Takes 2 units and divides as 1/4 and 3/4</p><p>
=================</p><p>
.yui-g – Standard grid, 1/2 – 1/2</p><p>
.yui-gb – Special grid, 1/3 – 1/3 – 1/3</p><p>
.yui-gc – Special grid, 2/3 – 1/3</p><p>
.yui-gd – Special grid, 1/3 – 2/3</p><p>
.yui-ge – Special grid, 3/4 – 1/4</p><p>
.yui-gf – Special grid, 1/4 – 3/4</p><p>
===============</p><p>
</div>
</div>

<div style="float:right;width:48%;xalign:center;">
<h3 style="margin: 10px; padding: 10px; background: #164978 border: 1px solid #ddd; overflow:auto; color: #7b11a3; background-color: #85d6fd; border-color: #d08ee0;"><?php _e('If you want All Sidebars Always on the Right Side and Inner and Outer sidebars on theat right side resize equally according to the YUI CSS Grids Layout, then ere is the code', hybrid_get_textdomain() ); ?></h3>
<textarea name="code" class="HTML">	
		<div id="bd">
<div  class="yui-g">
<div class="yui-u first">
<?php _e('load the main content', hybrid_get_textdomain() ); ?>
</div>
<!--?php
/**
 * Footer Template
?-->		
<div class="yui-u">
<div class="yui-g first">
<div class="yui-u first">
<?php get_sidebar( 'primary' ); // Loads the sidebar-primary.php template. ?>
</div><!-- .yui-u first -->	
<div class="yui-u">
<?php get_sidebar( 'secondary' ); // Loads the sidebar-secondary.php template. ?>
</div><!-- .yui-u -->
</div><!-- .yui-g first -->
</div><!-- .yui-u -->
</div><!-- .yui-g-->	
</div><!-- #bd -->
</textarea>	
</div>		
</div>
<?php }

/**
 * This is copied from the way obandes wordpress theme calls the YUI CSS and YAHOO JS Scripts
 * It is then adapted into the yuiwp theme configuration
 * This setting follows previous yui-css-grids setting
 *
 */
if ( ! function_exists('yahoowp_init' ) ) {
    function yahoowp_init() {
        global $is_lynx, $is_gecko, $is_IE, $is_opera, $is_NS4, $is_safari, $is_chrome, $is_iphone, $yahoowp_current_theme_name, $yahoowp_version;
        $page = basename($_SERVER['REQUEST_URI']);


        if( file_exists( get_stylesheet_directory().'/library/' ) ){
            $stylesheet_directory= get_stylesheet_directory_uri();
        }else{
            $stylesheet_directory= get_template_directory_uri();
        }
$flag = false;
        if ( ! is_admin() and !preg_match( "|^wp-login\.php|si",$page)) {

        $locate_file = locate_template( array('library/css/reset/reset.css') );

        if( file_exists( $locate_file ) ){
            wp_register_style('html5reset',
            $stylesheet_directory.'/library/css/reset/reset.css',
            false, $yahoowp_version );

        }else{
            wp_register_style('html5reset',
             'http://yui.yahooapis.com/2.8.0r4/build/reset-fonts-grids/reset-fonts-grids.css',
             false,
             $yahoowp_version
             );
        }

        wp_enqueue_style( 'html5reset');

        $locate_file = locate_template( array('library/css/grids/grids.css') );

        if( file_exists( $locate_file ) ){
            wp_register_style( 'html5grids',
                                $stylesheet_directory.'/library/css/grids/grids.css',
                                false,
                                $yahoowp_version
                            );

        }else{
            $flag = true;
        }

        wp_enqueue_style( 'html5grids');

        $locate_file = locate_template( array('library/css/fonts/fonts.css') );

        if( file_exists( $locate_file ) ){
            wp_register_style(
                    'html5fonts',
                    $stylesheet_directory.'/library/css/fonts/fonts.css',
                    false,
                    $yahoowp_version
            );

        }else{
            $flag = true;
        }

        wp_enqueue_style( 'html5fonts');

            wp_register_style('style',
            get_stylesheet_uri(),
            array( 'html5reset' ),
            $yahoowp_version
            );

        wp_enqueue_style( 'style' );


        if($flag == true ){
            wp_register_script('yui-css',
            'http://yui.yahooapis.com/2.8.0r4/build/yuiloader/yuiloader-min.js',
            false,
            $yahoowp_version
            );
        }
        wp_enqueue_script('yui-css');

            wp_register_script(
                'yui',
                get_stylesheet_directory_uri().'/library/js/yui.js',
                array('yui-css'), $yahoowp_version
            );
            wp_enqueue_script('yui');

            wp_register_script(
                'yahoowp',
            get_stylesheet_directory_uri().'/library/js/yahoowp.js',
            array('jquery'),
            $yahoowp_version
            );

        wp_enqueue_script('yahoowp');

        }
		
    $locate_file = locate_template( array('library/css/yahoowph.css') );

        if( file_exists( $locate_file ) ){
            wp_register_style('html5main',
            $stylesheet_directory.'/library/css/yahoowph.css',
            false, $yahoowp_version );

        }else{
            wp_register_style('html5main',
             'http://cdn.cheaphosts.us/assets/yahoowp/yahoowph.css',
             false,
             $yahoowp_version
             );
        }

        wp_enqueue_style( 'html5main');
		

        if($is_IE){

            $locate_file = locate_template('library/js/html5shiv/html5shiv.js');

            if( empty( $locate_file ) ){
                wp_register_script('html5shiv',
                $stylesheet_directory.'/library/js/html5shiv/html5shiv.js', array(), '3', false );
            }else{
                wp_register_script('html5shiv', 'http://html5shiv.googlecode.com/svn/trunk/html5.js', array(), '3', false);
            }

            wp_enqueue_script('html5shiv');
        }
    }
}

} endif; /* this ends if_function_exists before starting all you css grids */

?>