<?php
/**
 * After Singular Sidebar Template
 *
 * The After Singular sidebar template houses the HTML used for the 'Utility: After Singular' 
 * sidebar.  If widgets are present, they will be displayed.  If no widgets are present and the reader
 * is viewing a singular post, a tabbed list of related posts will be displayed by recent/popular.
 *
 * @package News
 * @subpackage Template
 */

if ( is_active_sidebar( 'after-singular' ) ) : ?>

	<div id="utility-after-single" class="sidebar utility">

		<?php dynamic_sidebar( 'after-singular' ); ?>

	</div><!-- #sidebar-after-singular .utility -->

<?php elseif ( is_singular( 'post' ) ) : ?>


	<div id="utility-after-single" class="utility">
	
	<h3 class="breadcrumbs" style="">&raquo;&nbsp;&rang;&nbsp;<?php _e('More and Related News', hybrid_get_textdomain() ); ?></h3>
   <div id="afterSingularTabView" class="yui-navset">
                    <ul class="yui-nav">
					<li class="selected"><a href="#singular-post-tabs-1"><em><?php _e( 'By Tags', hybrid_get_textdomain() ); ?></em></a></li>
					<li><a href="#singular-post-tabs-2"><em><?php _e( 'Previous', hybrid_get_textdomain() ); ?></em></a></li>
					<li><a href="#singular-post-tabs-3"><em><?php _e( 'Popular', hybrid_get_textdomain() ); ?></em></a></li>
					<li><a href="#singular-post-tabs-4"><em><?php _e( 'Next', hybrid_get_textdomain() ); ?></em></a></li>
					<li><a href="#singular-post-tabs-5"><em><?php _e( 'By Content', hybrid_get_textdomain() ); ?></em></a></li>
			<?php if(current_theme_supports('google-related-news')) { ?>					
					<li><a href="#singular-post-tabs-6"><em><?php _e( 'from Google', hybrid_get_textdomain() ); ?></em></a></li>
					<?php }  ?>
				</ul><!-- .ui-tabs-nav -->
				
			<div class="yui-content">
			
		<div id="singular-post-tabs-1">
				<h4 class="breadcrumbs"><?php printf( __( '&raquo;&nbsp;&rang;&nbsp;Tagged: %s', 'yahoowp' ), get_the_tag_list('&nbsp;&nbsp;') ) ?></h4>
				<?php echo do_shortcode( '[related-by-tag limit="5"]' );?>
				</div><!-- #singular-post-tabs-1 .series -->	

				<div id="singular-post-tabs-2">
			<?php $loop = new WP_Query( array( 'cat__in' => $cat__in, 'posts_per_page' => 6, 'ignore_sticky_posts' => true ) ); ?>
					<?php $i = 0; ?>		
					<div class="yui-g">		
					<?php if ( $loop->have_posts() ) : ?>
						<h4 class="breadcrumbs"><?php printf( __( '&raquo;&nbsp;&rang;&nbsp;Previous 5 in: %s', 'papuamerdeka' ), get_the_category_list(', ') ) ?></h4>										
						<div class="yui-u first">
						<ul class="listing">
						<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
							<?php if ( ++$i == 4 ) { ?>
								</ul></div>
								
								<div class="yui-u">
								<ul class="listing">
							<?php } ?>
							<?php the_title( '<li><a href="' . get_permalink() . '" title="' . the_title_attribute( 'echo=0' ) . '">', '</a></li>' ); ?>
						<?php endwhile; ?>
						</ul></div>
					<?php endif; ?>
		</div><!-- .yui-g -->				
			</div><!-- #singular-post-tabs-1 .series -->				
				
				<div id="singular-post-tabs-3">

					<?php $loop = new WP_Query( array( 'cat__in' => $cat__in, 'orderby' => 'comment_count', 'posts_per_page' => 6, 'ignore_sticky_posts' => true ) ); ?>

					<?php $i = 0; ?>

					<?php if ( $loop->have_posts() ) : ?>

						<div class="yui-g">
						<div class="yui-u first">
						<ul class="listing">

						<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

							<?php if ( ++$i == 4 ) { ?>
							</ul></div>
								<div class="yui-u">
								<ul class="listing">
							<?php } ?>

							<?php the_title( '<li><a href="' . get_permalink() . '" title="' . the_title_attribute( 'echo=0' ) . '">', '</a></li>' ); ?>

						<?php endwhile; wp_reset_query(); ?>

						</ul></div>
				</div><!-- .yui-g -->

					<?php endif; ?>
				</div><!-- #singular-post-tabs-3 .series -->				
					
				<div id="singular-post-tabs-4">
				<h4 class="breadcrumbs"><?php printf( __( '&raquo;&nbsp;&rang;&nbsp;Next 5 in: %s', 'papuamerdeka' ), get_the_category_list(', ') ) ?></h4>
					<?php echo do_shortcode( '[more-articles limit="5"]' );?>
		</div><!-- #singular-post-tabs-4 .series -->
		
		<div id="singular-post-tabs-5">	
			<!-- YOUR DATA GOES HERE -->
 	<h4 class="breadcrumbs" title="<?php _e('Related by Taxonomies', 'yahoowp') ?>">
	<strong>&raquo;&nbsp;&rang;&nbsp;<?php _e('Related News by Content & else by Recent Update&nbsp;', hybrid_get_textdomain() ); ?></strong></h4>
	
	<?php the_widget ('Cakifo_Widget_Related_Posts');?>		
				 					
			</div><!-- #singular-post-tabs-5 .series -->
			
		<div id="singular-post-tabs-6">	
		
<?php if(current_theme_supports('google-related-news')) { ?>
		<div class="widget">
			<h4 class="breadcrumbs"><?php _e('&raquo;&nbsp;&rang;&nbsp;Related from Google.com&nbsp;', hybrid_get_textdomain() ); ?></h4>
	<div class="widget-inside">
		<ul class="listing">
	<?php echo do_shortcode('[related-from-google]'); ?>
		</ul>
	</div>
		</div>
		<?php }  ?>

		</div><!-- #singular-post-tabs-6 .series -->		
				
			</div><!-- .yui-content -->
			
<script type="text/javascript" charset="utf-8">
var oTabView = new YAHOO.widget.TabView("afterSingularTabView");
</script>
		</div><!-- #afterSingularTabView -->	
		
<!--?php echo apply_atomic_shortcode( 'entry_meta', '<div class="widget">' . __( '<span class="share">Share this on:</span> [entry-mixx-link] [entry-delicious-link] [entry-digg-link] [entry-facebook-link] [entry-twitter-link]', hybrid_get_textdomain() ) . '</div>' ); ?-->	

	</div><!-- #id="sidebar-after-singular" class="sidebar utility" -->

<br clear="both">

<?php elseif ( is_singular(array ('post_type' => 'book', 'paper', 'faq', 'editorial','podcast','slideshow','video','campaign','document','laniwone') ) && (function_exists('pippin_related_posts')) ) : ?>
	<div id="utility-after-single" class="sidebar utility">
<?php echo pippin_related_posts(); ?> 
	</div> 
	
<br clear="both">
<?php elseif ( is_attachment() ) : ?>
<div class="clear doc_sep">&nbsp;</div>
<div id="utility-after-single" class="utility" style="float:left;margin-top:20px;">

			<div class="commentsmyAccordion">					
		<div class="yui-cms-accordion multiple fast fixIE" rel="bounceOut" id="mylist-second-accordion">
	<?php if ( wp_attachment_is_image( get_the_ID() ) ) { // Only show attachment meta for images for now. ?>
 		<div class="yui-cms-item">
	<h3breadcrumbs><a href="#" class="accordionToggleItem" title="click to expand">&raquo;&nbsp;&rang;&nbsp;<?php _e( 'Current Gallery', hybrid_get_textdomain() ); ?></a></h3>
			<?php $gallery = do_shortcode( sprintf( '[gallery id="%1$s" exclude="%2$s" columns="7" numberposts="21" orderby="meta_value_num"]', $post->post_parent, get_the_ID() ) ); ?>
				<?php if ( !empty( $gallery ) ) { ?>
				<div class="bd">
					<div class="fixed">
				<?php echo $gallery; ?>
				</div><!-- .attachment-meta -->
		</div>
		<?php } ?>
		</div>
		<?php } ?>
					<div class="yui-cms-item"> 
					<h3><a href="#" class="accordionToggleItem" title="click to expand">&raquo;&nbsp;&rang;&nbsp;<?php _e('Image Meta&nbsp;', hybrid_get_textdomain() ); ?></a></h3>
				<div class="bd"> 
				<div class="fixed"> 
				<?php news_fitted_image_info(); ?>				
				</div>
				</div>
				</div>	
		</div>
		</div>			
		</div>
		<div id="utility-after-single" class="utility" style="float:left;margin-top:20px;margin-left:15px;">
		<?php include( get_stylesheet_directory() . '/library/content/yui-carousel-gallery.html' ); // Loads the loop-meta.php template. ?>
	</div>
<div class="clear"></div>
<?php endif; ?>